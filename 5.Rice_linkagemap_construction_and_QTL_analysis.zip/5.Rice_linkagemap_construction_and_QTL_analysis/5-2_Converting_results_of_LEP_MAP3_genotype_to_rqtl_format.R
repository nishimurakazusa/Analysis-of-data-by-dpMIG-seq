

chr_list = c( paste0("chr0",1:9), paste0("chr",10:12))
chr_list_name = chr_list
inverse_list = c(3,4,5,7,9,11)

i = 4
dir.create("genodata")

for(i in 1:length(chr_list)){
  ###
  marker_name = read.table(file=paste0(chr_list[i],"/cut_p_fil.call.txt"), skip=7)
  genotype_table = read.table(file=paste0(chr_list[i],"/genotypes.",chr_list[i],".txt"),
                              sep="\t")
  colnames(genotype_table) = genotype_table[2,]
  genotype_table = genotype_table[c(7:nrow(genotype_table)),]
  
  genotype_table[genotype_table == "1 1"] =  "A" 
  genotype_table[genotype_table == "1 2"] =  "H"
  genotype_table[genotype_table == "2 1"] =  "H"
  genotype_table[genotype_table == "2 2"] =  "B"
  #genotype_table[genotype_table == "0 0"] =  "-"
  
  #j=1
  #chrpos = data.frame(matrix(NA),nrow=nrow(genotype_table),ncol =2 )
  for(j in as.numeric(genotype_table$MARKER) ){
    genotype_table[genotype_table$MARKER == j,1] = paste0(marker_name[j,1],"_",marker_name[j,2] )
    #chrpos[genotype_table$MARKER == j,1] = marker_name[j,1]
    #chrpos[genotype_table$MARKER == j,1] = marker_name[j,2]
  }
  
  group = read.table( file=paste0(chr_list[i],"/map.txt"))
  group_table = table(group)
  
  pos = as.numeric(genotype_table$MALE_POS) 
  pos_c= which( pos - c(0,pos[1:(length(pos)-1)])   <   0   ) - 1
  pos_c = c(pos_c,nrow(genotype_table))
  
  if(length(pos_c) >= 2){
    pos_c =  c(pos_c[1],  (pos_c[2:length(pos_c)] - pos_c[1:(length(pos_c)-1)]) )
  }
  
  #k=1
  chr_num = 0
  for(k in 1:(length(pos_c)) ){
    chr_num= c(chr_num ,   rep(paste0(chr_list[i],"_", k) , pos_c[k] )  )
  }
  
  
  ###
  genotype_table$CHR = chr_num[-1]
  
  genotype_table =  genotype_table[genotype_table$CHR == names(table(genotype_table$CHR))[1], ]
  
  write.csv(genotype_table,
            file=paste0( "genodata/map_geno_",chr_list[i],".csv")) 

  }


####
genotype_table_all = read.csv(file=paste0( "genodata/map_geno_",chr_list[1],".csv"),
                              row.names = 1,header = T,stringsAsFactors = F
) 
for(i in 2:12){
  genotype_table_all = rbind(genotype_table_all,
                             read.csv(file=paste0( "genodata/map_geno_",chr_list[i],".csv"),
                                      row.names = 1,header = T,stringsAsFactors = F
                             ) 
  )
}

#######
write.csv(genotype_table_all,file="genotype_table_all.csv")

#chr_names = names(table(genotype_table_all$CHR))[table(genotype_table_all$CHR) < 30]

genotype_table_for_qtl = genotype_table_all

#chr_names
#i=1
#for(i in 1:length(chr_names)){ 
#  genotype_table_for_qtl[genotype_table_all$CHR == chr_names[i], 2] = 0
#}

genotype_table_for_qtl = genotype_table_for_qtl[genotype_table_for_qtl$CHR != 0,]
genotype_table_for_qtl = genotype_table_for_qtl[,c(1,2,3,7:ncol(genotype_table_for_qtl))]
colnames(genotype_table_for_qtl)[1:3] = c("id","","")
colnames(genotype_table_for_qtl)[4:ncol(genotype_table_for_qtl)] = 1:(ncol(genotype_table_for_qtl)-3)


#####################
genotype_table_for_qtl

for(i in 1:12){
  genotype_table_for_qtl[genotype_table_for_qtl[,2] == paste0(chr_list[i],"_1")     ,2] = chr_list[i]
}
unique( genotype_table_for_qtl[,2] )

i=1

for(i in inverse_list){
  x= genotype_table_for_qtl[ genotype_table_for_qtl[,2] == chr_list[i], ]
  x[,3] = max(x[,3])- x[,3]
  message(paste0(x[1:10,1]))
  genotype_table_for_qtl[ genotype_table_for_qtl[,2] == chr_list[i], ] = x[nrow(x):1,]
}

pos_dif= c(genotype_table_for_qtl[2:nrow(genotype_table_for_qtl),3],0) - genotype_table_for_qtl[,3]
hist(pos_dif)

genotype_table_for_qtl_2 = genotype_table_for_qtl
for(i in 1:12){
  genotype_table_for_qtl_2[ genotype_table_for_qtl[,2] == chr_list[i],2 ] = chr_list_name[i]
}

write.csv(genotype_table_for_qtl_2, file="genotype_table_for_qtl.csv",
          quote = F,
          row.names = F)


chrpos= t( data.frame( strsplit( genotype_table_for_qtl[,1],"_") ) )
rownames(chrpos) = 1:nrow(chrpos)

data =  data.frame( chrpos, genotype_table_for_qtl[,c(1,3)]  )
colnames(data) = c("Chromosome","Physical_position_Mb","Marker name","Genetic_position_cM")

data[,2] =as.numeric(data[,2])/1000000

library(ggpubr)
chr_size = read.table(file="IRGSP-1.0_genome.fasta.fai")


for(i in  1:12){
  
  data2 = data[ data[,1] == chr_list[i] , ]
  x = gghistogram(data2 , x="Physical_position_Mb",
                  title = paste(chr_list[i]), size=0.2,
                  binwidth = 1) 
  x = x + ggpubr::font("xy.text",size=8) 
  x = x + geom_vline( xintercept = chr_size[i,2]/1000000, color = "red",
                      linetype="dashed", size=0.2)
  message(paste0( chr_size[i,2]/1000000))
  
  x =  ggpubr::ggpar(x,font.x = c(8, "bold", "#000000"),
                     font.y = c(8, "bold", "#000000"), 
                     ylab = "Frequency",
                     xlim=c(0,50),ylim = c(0,50))
  assign(paste0("hi",i),x) 
}

gg= ggpubr::ggarrange(hi1, hi2, hi3, hi4, hi5 ,hi6,
                      hi7,hi8,hi9,hi10,hi11,hi12,
                      #labels = LETTERS,
                      ggtheme = theme,
                      ncol=4,nrow=3,
                      font.label = list(size = 16, color = "black"),
                      widths = 10, heights = 5,
                      align = "hv") 
ggpubr::ggexport(gg, filename ="bp_maker_plot_rice_f2.pdf",width=8.5,height=5)


##ggpubr
for(i in  1:12){
  data2 = data[ data[,1] == chr_list[i] , ]
  #pp1 = ggpubr::ggscatter(data,"Physical map position", "Genetic map position")
  assign("x" , 
         ggpubr::ggscatter(data2, "Physical_position_Mb", "Genetic_position_cM",
                           title = paste(chr_list_name[i]),color= "black" ,size=1)   )
  x = x + ggpubr::font("xy.text",size=9)
  assign(paste0("pp",i) , 
         ggpubr::ggpar(x,font.x = c(9, "bold", "#000000"),font.y = c(9, "bold", "#000000")))
  
}

gg = ggpubr::ggarrange(pp1, pp2, pp3, pp4, pp5 ,pp6,
                       pp7,pp8,pp9,pp10,pp11,pp12,
                       #labels = LETTERS,
                       ncol=4,nrow=3,
                       font.label = list(size = 16, color = "black"),
                       widths = 8.5, heights = 6,
                       align = "hv") 


x=8
ggpubr::ggexport(gg, filename ="bp_cm_plot_rice_f2.pdf",
                 width=x*1,height=x*1*3/4)



####
library("qtl")
library("LinkageMapView")

dat1 <- read.cross("csvsr", ".", 
                   "genotype_table_for_qtl.csv",
                   "pheno_for_qtl.csv")
plot.map(dat1)

#newmap <- est.map(dat1, tol=1e-6, map.function="kosambi")

outfile = file.path(paste0("map_rice_F2.pdf"))
lmv.linkage.plot(dat1,outfile)

