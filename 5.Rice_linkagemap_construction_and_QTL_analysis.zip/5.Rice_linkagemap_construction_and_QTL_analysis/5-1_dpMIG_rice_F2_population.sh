
mkdir bam
mkdir fastq
mkdir reports
mkdir reports_trim

####p1 is Taichung 65, p2 is Takanari
####Merging three replicates of two parents
cat p1_1_1.fastq.gz p1_2_1.fastq.gz p1_3_1.fastq.gz > f000p1_1.fastq.gz
cat p1_1_2.fastq.gz p1_2_2.fastq.gz p1_3_2.fastq.gz > f000p1_2.fastq.gz
cat p2_1_1.fastq.gz p2_2_1.fastq.gz p2_3_1.fastq.gz > f000p2_1.fastq.gz
cat p2_1_2.fastq.gz p2_2_2.fastq.gz p2_3_2.fastq.gz > f000p2_2.fastq.gz

##Create a list for iterative processing
SEQLIBS=(f000p1 f000p2 f001 f002 f003 f004 f005 f006 f007 f008 \
f009 f010 f011 f012 f013 f014 f015 f016 f017 f018 f019 f020 f021 \
f022 f023 f024 f025 f026 f027 f028 f029 f030 f031 f032 f033 f034 \
f035 f036 f037 f038 f039 f040 f041 f042 f043 f044 f045 f046 f047 \
f048 f049 f050 f051 f052 f053 f054 f055 f056 f057 f058 f059 f060 \
f061 f062 f063 f064 f065 f066 f067 f068 f069 f070 f071 f072 f073 \
f074 f075 f076 f077 f078 f079 f080 f081 f082 f083 f084 f085 f086 \
f087 f088 f089 f090 f091 f092 f093 f094 f095 f096 f101 f102 f103 \
f104 f105 f106 f107 f108 f109 f110 f111 f112 f113 f114 f115 f116 \
f117 f118 f119 f120 f121 f122 f123 f124 f125 f126 f127 f128 f129 \
f130 f131 f132 f133 f134)


##Trimed by trimmomatic
for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/${seqlib}_1.fastq.gz rawdata/${seqlib}_2.fastq.gz \
fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_unpaired_output_1.fq \
fastq/${seqlib}_paired_output_2.fq fastq/${seqlib}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
done


thread=10
REF=../ref/rice/IRGSP-1.0_genome.fasta

#bwa index -p $REF $REF
#samtools faidx $REF
#gatk CreateSequenceDictionary -R $REF

for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

###
samtools mpileup -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/*.sorted.bam \
 | bcftools call -c -v -o dpMIG_rice_F2_samtools.vcf

vcftools --vcf dpMIG_rice_F2_samtools.vcf --max-missing 0.95 --minDP 10 --maf 0.20 \
--minQ 20 --min-alleles 2 --max-alleles 2  \
--recode --recode-INFO-all --out filtered_dpMIG_rice_F2_samtools.vcf


###Since some of the different chromosomes were sorted into same group, they were analyzed separately for each chromosome.
java -cp Lep-MAP3/bin ParentCall2 data = pedigree.txt  vcfFile = filtered_dpMIG_rice_F2_samtools.vcf.recode.vcf > p.call
java -cp Lep-MAP3/bin Filtering2 data=p.call  removeNonInformative=1 dataTolerance=0.001  > p_fil.call
java -cp Lep-MAP3/bin  SeparateChromosomes2 data=p_fil.call lodLimit=20  numThreads=6 > map.txt
sort map.txt|uniq -c|sort -n
java -cp Lep-MAP3/bin  OrderMarkers2 data=p_fil.call map=map.txt sexAveraged=1 numThreads=6 > order.txt
cut -f1,2 p_fil.call > cut_p_fil.call.txt
awk -v fullData=1 -f map2genotypes.awk order.txt > genotypes.txt


########Chromosome seperation based analysis
CHRS=(chr01 chr02 chr03 chr04 chr05 chr06 chr07 chr08 chr09 chr10 chr11 chr12)
for chr in ${CHRS[@]}; do
mkdir ${chr}
vcftools --vcf filtered_dpMIG_rice_F2_samtools.vcf.recode.vcf --chr ${chr} \
--recode --recode-INFO-all --out ${chr}/${chr}.samtools.vcf
java -cp Lep-MAP3/bin ParentCall2 data = pedigree.txt  vcfFile = ${chr}/${chr}.samtools.vcf.recode.vcf > ${chr}/p.call
java -cp Lep-MAP3/bin Filtering2 data=${chr}/p.call  removeNonInformative=1 dataTolerance=0.000001   > ${chr}/p_fil.call
java -cp Lep-MAP3/bin  SeparateChromosomes2 data=${chr}/p_fil.call lodLimit=5 numThreads=6 > ${chr}/map.txt
sort ${chr}/map.txt|uniq -c|sort -n
done

for chr in ${CHRS[@]}; do
java -cp Lep-MAP3/bin  OrderMarkers2 data=${chr}/p_fil.call map=${chr}/map.txt sexAveraged=1 \
grandparentPhase=1 numThreads=6 outputPhasedData=1  > ${chr}/order.txt
cut -f1,2 ${chr}/p_fil.call > ${chr}/cut_p_fil.call.txt
awk -v fullData=1 -f map2genotypes.awk ${chr}/order.txt > ${chr}/genotypes.${chr}.txt
done

###The LOD limit threshold was changed for chromosome 1 only.
CHRS=(chr01)
for chr in ${CHRS[@]}; do
mkdir ${chr}
vcftools --vcf filtered_dpMIG_rice_F2_samtools.vcf.recode.vcf --chr ${chr} \
--recode --recode-INFO-all --out ${chr}/${chr}.samtools.vcf
java -cp Lep-MAP3/bin ParentCall2 data = pedigree.txt  vcfFile = ${chr}/${chr}.samtools.vcf.recode.vcf > ${chr}/p.call
java -cp Lep-MAP3/bin Filtering2 data=${chr}/p.call  removeNonInformative=1 dataTolerance=0.000001   > ${chr}/p_fil.call
java -cp Lep-MAP3/bin  SeparateChromosomes2 data=${chr}/p_fil.call lodLimit=3 numThreads=6 > ${chr}/map.txt
sort ${chr}/map.txt|uniq -c|sort -n
done

for chr in ${CHRS[@]}; do
java -cp Lep-MAP3/bin  OrderMarkers2 data=${chr}/p_fil.call map=${chr}/map.txt sexAveraged=1 \
grandparentPhase=1 numThreads=6 outputPhasedData=1  > ${chr}/order.txt
cut -f1,2 ${chr}/p_fil.call > ${chr}/cut_p_fil.call.txt
awk -v fullData=1 -f map2genotypes.awk ${chr}/order.txt > ${chr}/genotypes.${chr}.txt
done
