

library("qtl")

dat1 <- read.cross("csvsr", ".", 
                          "genotype_table_for_qtl.csv",
                          "pheno_for_qtl.csv")
plot.map(dat1)

pdf(file="Map.pdf")
plot.map(dat1)
dev.off()
plot(dat1)
sum_dat1 = summary(dat1)
write.csv(sum_dat1$n.mar,file="sum_dat1_nmar.csv")
genotype_table_for_qtl_2 = read.csv(file="genotype_table_for_qtl.csv")
markers_chr_gpos = paste0(genotype_table_for_qtl_2[,2],"_",genotype_table_for_qtl_2[,3])
length( unique(markers_chr_gpos) )


######Summarize marker number

chrlist = c("01","02","03","04","05","06",
            "07","08","09","10","11","12")
res_df = data.frame(matrix(NA,nrow=length(chrlist),ncol=5))
res_df[,1] = chrlist
colnames(res_df)= c("Chromosome","Number of marker","Number of unique marker",
                    "Linkage map length","Average marker interval")

for(i in 1:length(chrlist)){
linkagemap = dat1[["geno"]][[chrlist[i]]][["map"]]
  res_df[i,2] = length(linkagemap)
  res_df[i,3] = length(unique(linkagemap))
  res_df[i,4] = max(linkagemap)
  res_df[i,5] = max(linkagemap)/(length(unique(linkagemap))-1)
}

write.csv(res_df,file="linkagemap_summary.csv")




#######
pdf(file="Geno_image_F2_not_imutated.pdf")
geno.image(dat1)
dev.off()
pdf(file="Rf_image_F2_not_imutated.pdf")
plotRF(dat1)
dev.off()

png(file="Rf_image_F2_not_imutated.png", height=1000,width=1000)
plotRF(dat1)
dev.off()

##########QTL analysis
testmapimp <- calc.genoprob(dat1, step=1) 
out.simhk <- scanone(testmapimp, pheno.col=1, method="hk")
operms <- scanone(testmapimp, n.perm=1000, method="hk",n.cluster=4,pheno.col = 1)
summary(out.simhk, perms=operms, alpha=0.05, pvalues=TRUE)
summary(operms)
write.csv( summary(out.simhk, perms=operms, alpha=0.05, pvalues=TRUE),
           file="sum_im_qtl.csv" )

plot(out.simhk)
summary(out.simhk)
write.csv(out.simhk,file="out.simhk.csv")

out.simhk[out.simhk$lod > summary(operms)[1] ,  ]
plot(out.simhk)

#perform composite interval mapping (CIM) (based on Haley-Knott regression)
out.cimhk <- cim(testmapimp, n.marcovar=5, pheno.col=1, method="hk")
#Perform a permutation test.
operm <- cim(testmapimp,n.perm=1000,n.marcovar=5,pheno.col = 1, method="hk")
#save(operm,file="operm1.rda")
#load("operm1.rda")
summary(operm)

##To write down the QTL peaks that are significant at the 5% level
summary(out.cimhk, perms=operm, alpha=0.05, pvalues=TRUE)
plot(out.cimhk)
abline(summary(operm)[1],0,col="red" )

plot(out.cimhk)
abline(summary(operm)[1],0,col="red" )

pdf(file="Fig.2b_cim_dgh.pdf",width=10,height=5)
plot(out.cimhk)
abline(summary(operm)[1],0,col="red" )
dev.off()

summary(out.cimhk)
write.csv(out.cimhk,file="out.cimhk.csv")
out.cimhk[out.cimhk$lod > summary(operm)[1] ,  ]
write.csv( summary(out.cimhk, perms=operm, alpha=0.05, pvalues=TRUE),
           file="sum_cim_qtl.csv" )


#Results of IM and CIM 
layout(matrix(1:1, ncol=1))
plot(out.simhk, out.cimhk, col=c("blue", "red"))

pdf(file="_qtl_result_f2_not_imputated.pdf")
layout(matrix(1:1, ncol=1))
plot(out.simhk, out.cimhk, col=c("blue", "red"))
dev.off()


pdf(file="_qtl_result_f2_not_imputated_cim.pdf",height =6,width=6)
layout(matrix(1:1, ncol=1))
plot(out.cimhk)
dev.off()

#
summary(operm)
summary(operms)

res_perm= cbind(summary(operm),summary(operms) )
colnames(res_perm) = c("cim","im")
res_perm
write.csv(res_perm,file="res_perm.csv")

summary(out.cimhk)

testmapimp = sim.geno(testmapimp)
layout(matrix(1:1, ncol=1,nrow=1))

effectplot(testmapimp, mname1="chr07_10928481", pheno.col=1)
layout(matrix(1:1, ncol=1))

chr10_1_out.cimhk = out.cimhk[out.cimhk$chr == "10_1" ,]

effectplot(testmapimp, mname1="chr10_17317955", pheno.col=1)
layout(matrix(1:1, ncol=1))

chr3_1_out.cimhk = out.cimhk[out.cimhk$chr == "03_1" ,]

effectplot(testmapimp, mname1="chr03_24900593", pheno.col=1)
layout(matrix(1:1, ncol=1))

effectplot(testmapimp, mname1="chr06_2855310", pheno.col=1)
layout(matrix(1:1, ncol=1))

res_operms= summary(operms)
threshold_simhk = out.simhk[out.simhk[,3] > res_operms[1], ]
threshold_simhk

res_operm= summary(operm)
threshold_cimhk = out.cimhk[out.cimhk[,3] > res_operm[1], ]
threshold_cimhk

write.csv(res_operm, file="res_operm.csv")
write.csv(res_operms, file="res_operms.csv")
write.csv(threshold_cimhk, file="threshold_cimhk_for_table.csv")
write.csv(threshold_simhk, file="threshold_simhk_for_table.csv")

write.csv(out.cimhk,file="QTL_result.csv")



#######Calculate average cM for each chromosomes
empty_df = matrix(NA,nrow=12,ncol= 4)
colnames(empty_df) = c("no_of_maker","no_of_unique_maker","map_length","average_maker_interval")
chr_list2= c("01","02","03","04","05","06","07","08","09","10","11","12")
row.names(empty_df) = chr_list

i=1

for(i in 1:12){
  
  cha_no = chr_list2[i]
  dat1
  len_map = length( dat1[["geno"]][[cha_no]][["map"]] )
  len_map
  empty_df[i,1] =  len_map
  
  uni_maker_map = unique( dat1[["geno"]][[ cha_no]][["map"]] )
  uni_maker_map
  
  empty_df[i,2] =  length( uni_maker_map )
  
  max_map = max( dat1[["geno"]][[ cha_no]][["map"]] )
  empty_df[i,3] = max_map
  
  max_map/(length( uni_maker_map ) - 1 )
  
  empty_df[i,4] = max_map/(length( uni_maker_map ) - 1 )
  
}

empty_df
sum(empty_df[,1] )
sum(empty_df[,2] )

write.csv(empty_df,file="linkagemap_summary_res_rice_f2.csv")



###Ghd7
###9,155,030 
###9,152,377 
chr7_marker= dat1[["geno"]][["07"]][["data"]]

chr7_marker[,colnames(chr7_marker) == "chr07_9573539"]

data3= data.frame(chr7_marker[,colnames(chr7_marker) == "chr07_9573539"],
                  dat1[["pheno"]][["DTH"]])

str(data3)
table(data3[,1])
data3[data3[,1] == 1, 1] = "A" 
data3[data3[,1] == 2, 1] = "H"
data3[data3[,1] == 3, 1] = "B"

library(ggpubr)
data3[,1] <-  factor( data3[,1], levels = c("A", "H", "B"))
colnames(data3) = c("chr07_9573539","DTH")

gg3 = ggboxplot(data3,x = "chr07_9573539", y="DTH",color= "chr07_9573539",
          palette =c("#00AFBB", "#E7B800", "#FC4E07"),
          add = "jitter", shape ="chr07_9573539" )
gg3


#install.packages("multcomp")
library(multcomp)
res_data3<-aov(DTH~chr07_9573539,d=data3)
summary(res_data3)
res2_data3<-glht(res_data3,linfct=mcp(chr07_9573539="Tukey"))
summary(res2_data3)
cld(res2_data3)




#####QTL on 03chr
chr3_marker= dat1[["geno"]][["03"]][["data"]]
chr3_marker[,colnames(chr3_marker) == "chr03_25103880"]
data4= data.frame(chr3_marker[,colnames(chr3_marker) == "chr03_25103880"],
                  dat1[["pheno"]][["DTH"]])

str(data4)
table(data4[,1])
data4[data4[,1] == 1, 1] = "A" 
data4[data4[,1] == 2, 1] = "H"
data4[data4[,1] == 3, 1] = "B"
data4

library(ggpubr)
data4[,1] <-  factor( data4[,1], levels = c("A", "H", "B"))
colnames(data4) = c("chr03_25103880","DTH")

gg4 = ggboxplot(data4,x = "chr03_25103880", y="DTH",color= "chr03_25103880",
               palette =c("#00AFBB", "#E7B800", "#FC4E07"),
               add = "jitter", shape ="chr03_25103880" )
gg4

res_data4<-aov(DTH~chr03_25103880,d=data4)
summary(res_data4)
res2_data4<-glht(res_data4,linfct=mcp(chr03_25103880="Tukey"))
summary(res2_data4)
cld(res2_data4)


##Ehd1####
##17,081,344 
##17,076,098 

chr10_marker= dat1[["geno"]][["10"]][["data"]]

chr10_marker[,colnames(chr10_marker) == "chr10_16824700"]

data5= data.frame(chr10_marker[,colnames(chr10_marker) == "chr10_16824700"],
                  dat1[["pheno"]][["DTH"]])

str(data5)
table(data5[,1])
data5[data5[,1] == 1, 1] = "A" 
data5[data5[,1] == 2, 1] = "H"
data5[data5[,1] == 3, 1] = "B"


library(ggpubr)

data5[,1] <-  factor( data5[,1], levels = c("A", "H", "B"))
colnames(data5) = c("chr10_16824700","DTH")
gg5 = ggboxplot(data5,x = "chr10_16824700", y="DTH",color= "chr10_16824700",
               palette =c("#00AFBB", "#E7B800", "#FC4E07"),
               add = "jitter", shape ="chr10_16824700" )
gg5

res_data5<-aov(DTH~chr10_16824700,d=data5)
summary(res_data5)
res2_data5<-glht(res_data5,linfct=mcp(chr10_16824700="Tukey"))
summary(res2_data5)
cld(res2_data5)


#library(cowplot)
ggar = ggpubr::ggarrange(gg4,gg3,gg5,ncol = 3,nrow = 1, align = "hv") 
ggpubr::ggexport(ggar, filename ="f2_gene_effect_qtl.pdf",width=10,height=5)


###chr06_2265438
chr6_marker= dat1[["geno"]][["06"]][["data"]]
chr6_marker[,colnames(chr6_marker) == "chr06_2265438"]
data6= data.frame(chr6_marker[,colnames(chr6_marker) == "chr06_2265438"],
                  dat1[["pheno"]][["DTH"]])

str(data6)
table(data6[,1])
data6[data6[,1] == 1, 1] = "A" 
data6[data6[,1] == 2, 1] = "H"
data6[data6[,1] == 3, 1] = "B"

library(ggpubr)
data6[,1] <-  factor( data6[,1], levels = c("A", "H", "B"))
colnames(data6) = c("chr06_2265438","DTH")
gg6 = ggboxplot(data6,x = "chr06_2265438", y="DTH",color= "chr06_2265438",
                palette =c("#00AFBB", "#E7B800", "#FC4E07"),
                add = "jitter", shape ="chr06_2265438" )
gg6

#library(cowplot)
res_data6<-aov(DTH~chr06_2265438,d=data6)
summary(res_data6)
res2_data6<-glht(res_data6,linfct=mcp(chr06_2265438="Tukey"))
summary(res2_data6)
cld(res2_data6)


########
cld(res2_data3)
cld(res2_data4)
cld(res2_data5)
cld(res2_data6)

########
ggar = ggpubr::ggarrange(gg4,gg6,gg3,gg5,ncol = 4,nrow = 1, align = "hv") 
ggpubr::ggexport(ggar, filename ="f2_gene_effect_qtl.pdf",width=12,height=4)

p_legend_gg5 <- lemon::g_legend(gg5)
grid::grid.newpage()
grid::grid.draw(p_legend_gg5)

ggsave(p_legend_gg5,file="legend_gg5.pdf")



#####chr03_25103880####
df = out.cimhk
data = data.frame(df[df$chr == "03",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "chr03", 5] = NA
write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)
gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
start = 45
end   = 60

QTL_chr03_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
  geom_line() +
  ggtitle("QTL chr03")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_chr03_genetic = QTL_chr03_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                                  color = 1, linetype="solid", size=0.5)+ 
  scale_x_continuous(breaks=seq(start,end,by=1), limits=c(start,end))

#guides(colour=FALSE)

QTL_chr03_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)
phy_range= range(na.omit(  data[data$cM >start & data$cM < end,  6] )  )

QTL_chr03_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(floor(phy_range[1]),ceiling(phy_range[2]),by=0.2), limits=c(floor(phy_range[1]),ceiling(phy_range[2]) ))


QTL_chr03_physical = QTL_chr03_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),
                                                    color = 1, linetype="solid", size=0.5)

genes_name_03= c("OsLBD38","OsPIPK1","OsCOL9/OsCOL10","phyA","OsWDR5a")
genes_pos_03= c(22976955,28941973,28686958,29930025,29486017)

for(k in 1:5){
QTL_chr03_physical = QTL_chr03_physical + geom_vline(  xintercept = genes_pos_03[k]/(10^6) ,　　
                                                       linetype="solid",
                                                    color = "#FF0000", 
                                                    size=0.5)
}
QTL_chr03_physical

(gg = ggpubr::ggarrange(QTL_chr03_genetic,QTL_chr03_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_chr03_genetic_physicalmap.pdf",width=8,height=4)












#####chr07_9573539####
df = out.cimhk
data = data.frame(df[df$chr == "07",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "chr07", 5] = NA
write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)
gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
start = 65
end   = 85

QTL_chr07_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
  geom_line() +
  ggtitle("QTL chr07")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_chr07_genetic = QTL_chr07_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                                    color = 1, linetype="solid", size=0.5)+ 
  scale_x_continuous(breaks=seq(start,end,by=1), limits=c(start,end))

#guides(colour=FALSE)

QTL_chr07_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)
phy_range= range(na.omit(  data[data$cM >start & data$cM < end,  6] )  )

QTL_chr07_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(floor(phy_range[1]),ceiling(phy_range[2]),by=1), limits=c(floor(phy_range[1]),ceiling(phy_range[2]) ))


QTL_chr07_physical = QTL_chr07_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),
                                                      color = 1, linetype="solid", size=0.5)

genes_name_07= c("SNB",
                 "Ghd7",
                 "OsMADS18")
genes_pos_07= c(7545547,
                9184534,
                25448633)

for(k in 1:length(genes_name_07)){
  QTL_chr07_physical = QTL_chr07_physical + geom_vline(  xintercept = genes_pos_07[k]/(10^6) ,　　
                                                         linetype="solid",
                                                         color = "#FF0000", 
                                                         size=0.5)
}
QTL_chr07_physical

(gg = ggpubr::ggarrange(QTL_chr07_genetic,QTL_chr07_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_chr07_genetic_physicalmap.pdf",width=8,height=4)










#####chr06_2855310####
df = out.cimhk
data = data.frame(df[df$chr == "06",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "chr06", 5] = NA
write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)
gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
start = 20
end   = 45

QTL_chr06_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
  geom_line() +
  ggtitle("QTL chr06")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_chr06_genetic = QTL_chr06_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                                    color = 1, linetype="solid", size=0.5)+ 
  scale_x_continuous(breaks=seq(start,end,by=1), limits=c(start,end))

#guides(colour=FALSE)

QTL_chr06_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)
phy_range= range(na.omit(  data[data$cM >start & data$cM < end,  6] )  )

QTL_chr06_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(floor(phy_range[1]),ceiling(phy_range[2]),by=0.2), limits=c(floor(phy_range[1]),ceiling(phy_range[2]) ))


QTL_chr06_physical = QTL_chr06_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),
                                                      color = 1, linetype="solid", size=0.5)

genes_name_06= c("OsGBP1",
                 "OsELF3-1/Hd17/ef7",
                 "RFT1",
                 "Hd3a")
genes_pos_06= c(1636572,
                2233133, 
                2925824, 
                2939005 )

for(k in 1:length(genes_name_07)){
  QTL_chr06_physical = QTL_chr06_physical + geom_vline(  xintercept = genes_pos_06[k]/(10^6) ,　　
                                                         linetype="solid",
                                                         color = "#FF0000", 
                                                         size=0.5)
}
QTL_chr06_physical

(gg = ggpubr::ggarrange(QTL_chr06_genetic,QTL_chr06_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_chr06_genetic_physicalmap.pdf",width=8,height=4)





#####chr10_16824700####
df = out.cimhk
data = data.frame(df[df$chr == "10",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "chr10", 5] = NA
write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)
gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
start = 60
end   = 80

QTL_chr10_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
  geom_line() +
  ggtitle("QTL chr10")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_chr10_genetic = QTL_chr10_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                                    color = 1, linetype="solid", size=0.5)+ 
  scale_x_continuous(breaks=seq(start,end,by=1), limits=c(start,end))

#guides(colour=FALSE)

QTL_chr10_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)
phy_range= range(na.omit(  data[data$cM >start & data$cM < end,  6] )  )

QTL_chr10_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(floor(phy_range[1]),ceiling(phy_range[2]),by=0.2), limits=c(floor(phy_range[1]),ceiling(phy_range[2]) ))


QTL_chr10_physical = QTL_chr10_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),
                                                      color = 1, linetype="solid", size=0.5)

genes_name_10= c("ehd2/rid1",
                 "Ehd1",
                 "OsMADS56")
genes_pos_10= c(15197103,
                17533310,
                21318423  )

for(k in 1:length(genes_name_07)){
  QTL_chr10_physical = QTL_chr10_physical + geom_vline(  xintercept = genes_pos_10[k]/(10^6) ,　　
                                                         linetype="solid",
                                                         color = "#FF0000", 
                                                         size=0.5)
}
QTL_chr10_physical

(gg = ggpubr::ggarrange(QTL_chr10_genetic,QTL_chr10_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_chr10_genetic_physicalmap.pdf",width=8,height=4)















########Histgram of F2#####
Takanari  = 91.9
Taichung  = 91.2
F2_pheno = dat1[["pheno"]][["DTH"]]

pa_pheno = data.frame(c("Takanari","Taichung 65"),c(Takanari, Taichung))

range(F2_pheno)

par(mfrow=c(3,1))
hist(Takanari, col = "#ff00ff40", border = "#ff00ff",  breaks=seq(75,108,1), main ="", ylim=c(0,10))
hist(Taichung, col = "#0000ff40", border = "#0000ff",  breaks=seq(75,108,1), main ="", ylim=c(0,10))
hist(F2_pheno, col = "#edae0040", border = "#edae00",  breaks=seq(75,108,1), main ="", ylim=c(0,40))
par(mfrow=c(1,1))



library(ggpubr)

###
data = pa_pheno
phe1 = ggpubr::gghistogram(data, 
                           x = "DGH",
                           add = "mean", 
                           #rug = TRUE,
                           color = "Line", 
                           fill = "Line",
                           palette =  c("#ff00ff", "#0000ff"),
                           binwidth = 1
)
phe1 = phe1 + ggpubr::font("xy.text",size=10) 
#phe1 = phe1 + geom_vline( xintercept = chr_size[i,2]/1000000, 
#                          color = "red", linetype="dashed", size=0.2)
phe1 =  ggpubr::ggpar(phe1,font.x = c(10, "bold", "#000000"),
                      font.y = c(10, "bold", "#000000"), 
                      ylab = "Frequency",
                      xlim=c(155,182),ylim = c(0,15), 
                      width = 10,height=2
) + theme(legend.position = "none")




RColorBrewer::display.brewer.all()


data = data.frame( c( rep("F2",length(F2_pheno)) ) ,F2_pheno)
colnames(data) = c("F2","DGH")
phe2 = gghistogram(data , x="DGH",
                   #title = paste("DGH"),
                   ylab = "Frequency",
                   xlab = "DGH",
                   #size=0.2,
                   binwidth = 1,
                   palette =  c("#edae00") ,
                   color =  "F2", 
                   fill = "F2"  ) 
phe2 = phe2 + ggpubr::font("xy.text",size=10) 
phe2 = phe2 + geom_vline( xintercept =  mean(Takanari),
                          color = "#ff00ff", linetype="dashed", size=0.5)
phe2 = phe2 + geom_vline( xintercept =  mean(Taichung),
                          color = "#0000ff", linetype="dashed", size=0.5)
phe2 =  ggpubr::ggpar(phe2,
                      font.x = c(10, "bold", "#000000"),
                      font.y = c(10, "bold", "#000000"), 
                      ylab = "Frequency",
                      xlab = "DTH",
                      xlim=c(75,110), lim = c(0,25)
)　+ theme(legend.position = "none")

phe2 + theme(legend.position="top")
phe2 + theme(legend.position = "none")
phe2


##
d1 = data.frame( c( rep("F2",length(F2_pheno)) ) ,F2_pheno,stringsAsFactors = F)
d2 =  pa_pheno
colnames(d1) = c("Line","DGH")
colnames(d2) = c("Line","DGH")
data = rbind(d1,d2)

p_for_label = ggpubr::gghistogram(data, 
                                  x = "DGH",
                                  #add = "mean", 
                                  #rug = TRUE,
                                  color = "Line", 
                                  fill = "Line",
                                  palette =  c("#edae00", "#ff00ff", "#0000ff"),
                                  binwidth = 1)
library("lemon")
p_legend <- lemon::g_legend(p_for_label)
grid::grid.newpage()
grid::grid.draw(p_legend)
(gg = ggpubr::ggarrange(p_legend,phe2,ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="pheno_plot_f2.pdf",width=4,height=5)

summary(dat1)
  

