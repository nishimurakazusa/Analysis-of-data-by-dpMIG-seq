
N_pos = c("m","m4n","m4n5n")
SP = c("blueberry","capsicum","hexaploid_wheat","melon","peach","quinoa",
       "radish","rice","soy","tetraploid_wheat","tomato")
hetero= c(1,0,0,0,1,0,
          0,0,0,0,1)

dp_limit = 10
#dp_limit = 5
#p1=1+2
#p2=2+2

data_amount= 0.3
#data_amount= 0.5

j=11
i=3

res_df_dp = data.frame(matrix(NA,ncol=6,nrow=66))

for(j in 1:11){
  #    for(j in c(4,7)){
  data_stat =  read.table(file=paste0("stat/stat_",SP[j],".txt" ), skip = 1,header =F )
  str(data_stat)
  
  data_stat = data_stat[seq(1,nrow(data_stat),by=2 ), ]
  
  
  data_stat[,4] = as.numeric(gsub(",","",　data_stat[,4]　))
  data_stat[,5] = as.numeric(gsub(",","",　data_stat[,5]　))
  str(data_stat)
  
  data_stat$Gb = data_stat[,5]/(10^9)
  data_stat$Gb
  
  data_stat$c_fac = (0.3/data_stat$Gb)/2
  
  
  for(i in 1:length(N_pos) ){
    #    for(i in c(1) ){
    message(paste0(SP[j],"_",N_pos[i]))
    
    line_name = data_stat[,1]
    line_name = sub(paste0("merged_rawdata/",SP[j],"/"),"",line_name)
    line_name = sub(paste0("_1.fastq.gz"),"",line_name)
    line_name
    line_name = data.frame( strsplit(line_name, "_") )
    Unzip <- function(...) rbind(data.frame(), ...)
    line_name <- do.call(Unzip, line_name)
    
    data_stat = cbind(data_stat,line_name)
    
    line_name =  line_name[ N_pos[i] == line_name[,1]  ,2 ]
    
    line1 = read.table(file=paste0("dp/",SP[j],"/",line_name[1],"_", N_pos[i],"_dp_output" ))
    line2 = read.table(file=paste0("dp/",SP[j],"/",line_name[2],"_", N_pos[i],"_dp_output" ))
    
    res_df_dp[2*6*(j-1)+2*(i-1)+1, 5] =  sum(line1[,3])
    res_df_dp[2*6*(j-1)+2*(i-1)+2, 5] =  sum(line2[,3])
    
    line1[,3] = line1[,3]*data_stat[data_stat[,11] == N_pos[i] & data_stat[,12] == line_name[1] ,][1,"c_fac"]
    line2[,3] = line2[,3]*data_stat[data_stat[,11] == N_pos[i] & data_stat[,12] == line_name[2] ,][1,"c_fac"]
    
    res_df_dp[2*6*(j-1)+2*(i-1)+1, 6] =  sum(line1[,3])
    res_df_dp[2*6*(j-1)+2*(i-1)+2, 6] =  sum(line2[,3])
    
    line1 = line1[line1[,3] >= dp_limit,]
    line2 = line2[line2[,3] >= dp_limit,]
    
    line1_chr_pos = paste0(line1[,1],"_",line1[,2])
    line2_chr_pos = paste0(line2[,1],"_",line2[,2])
    
    res_df_dp[2*6*(j-1)+2*(i-1)+1, 1] = N_pos[i]
    res_df_dp[2*6*(j-1)+2*(i-1)+1, 2] = SP[j]
    res_df_dp[2*6*(j-1)+2*(i-1)+1, 3] = line_name[1]
    res_df_dp[2*6*(j-1)+2*(i-1)+1, 4] = length(line1_chr_pos)
    
    res_df_dp[2*6*(j-1)+2*(i-1)+2, 1] = N_pos[i]
    res_df_dp[2*6*(j-1)+2*(i-1)+2, 2] = SP[j]
    res_df_dp[2*6*(j-1)+2*(i-1)+2, 3] = line_name[2]
    res_df_dp[2*6*(j-1)+2*(i-1)+2, 4] = length(line2_chr_pos)
    
  }
  
} 



colnames(res_df_dp) = c("Primer","sp","Line","DP_over_10","Total_mapped_base","Total_base/data_amount") 

res_df_dp2 = na.omit(res_df_dp)
write.csv(res_df_dp2,file=paste0( data_amount, "_res_df_dp.csv"))


res_df_dp2[res_df_dp2[,1] ==  "m",1] = "PS1"
res_df_dp2[res_df_dp2[,1] ==  "m4n",1] = "PS1_4"
res_df_dp2[res_df_dp2[,1] ==  "m4n5n",1] = "PS1_4-5"

genome_size= read.csv(file="genome_size.csv")

library(ggpubr)
options(scipen = 100000)
data = data.frame( res_df_dp2[,1:6], genome_size[,2:3])
write.csv(data,file=paste0( data_amount, "data_res_df_dp.csv"))

colnames(data) = c("Primer","sp","Line","DP_over_10","Total_mapped_base","Total_base/data_amount","Species","Genome_size") 

data$`Genome_size` = data$`Genome_size`/10^9
str(data)
gg= ggscatter(data,x = "Genome_size",y = "DP_over_10",
              color = "Primer",shape = "Species"  ) + 
  scale_shape_manual(values = 0:length(unique(data$Species)))

gg
ggsave(gg,file=paste0( data_amount,"_DP_plot.pdf"  ), height=4,width=8)


library(ggpubr)
options(scipen = 100000)

for(data_amount in 0.3){
  data= read.csv(file=paste0( data_amount, "data_res_df_dp.csv"), row.names = 1)
  data$species[data$species == "Common_wheat"] = "Hexaploid wheat"
  data$species[data$species == "Durum_wheat"]  = "Tetraploid wheat"
  
  colnames(data) = c("Primer set","sp","Line","Total base length DP over 10",
                     "Total mapped_base","Total base/data_amount",
                     "Species","Genome size Gb") 
  
  data$`Genome size Log2 Gb` = log2(data$`Genome size Gb`/1000000000)
  
  gg= ggscatter(data,x = "Genome size Log2 Gb",y = "Total base length DP over 10",
                color = "Primer set",shape = "Species"  ) + scale_shape_manual(values = 0:length(unique(data$Species)))
  #+ theme(text = element_text(size = 16))
  
  gg
  ggsave(gg,file=paste0("Fig.2a_",data_amount,"_DP_plot.pdf"  ), height=5,width=10)
}


