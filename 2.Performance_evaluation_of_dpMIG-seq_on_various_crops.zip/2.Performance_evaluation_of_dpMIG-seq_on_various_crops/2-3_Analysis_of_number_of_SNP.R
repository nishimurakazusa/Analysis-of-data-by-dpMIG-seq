
#require(pcaMethods)
require(rrBLUP)
require(qqman)
require(glmnet)
require(vcfR)
#filtering by depth
#set parameter
#b =10
FilterbyDP = function(b){
  
  filter_dp_progeny = b
  
  dp_pro = dp
  colnames(dp_pro)
  
  gt.score_pro = gt.score
  
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  
  gt.score_filtered = gt.score_pro
  
  all_data = data.frame(chrom,pos,gt.score_filtered)
  
  str(all_data)
  
  return(all_data)
}


# read compressed vcf file (*.vcf.gz)
#vcf_mig <- read.vcfR("filtered_3N_samtools.vcf.recode.vcf")

N_pos = c("m","m4n","m4n5n")
SP = c("blueberry","capsicum","hexaploid_wheat","melon","peach","quinoa",
       "radish","rice","soy","tetraploid_wheat","tomato")
hetero= c(1,0,0,0,1,0,
          0,0,0,0,1)

dp_limit = 10
p1=1+2
p2=2+2


res_df= data.frame(matrix(NA, nrow = length(N_pos)*20, ncol = 4))
res_df[,1] = N_pos 
j=4
for(j in 1:length(SP)){
  
  data_stat =  read.table(file=paste0("stat/stat_",SP[j],".txt" ), skip = 1,header =F )
  str(data_stat)
  
  data_stat = data_stat[seq(1,nrow(data_stat),by=2 ), ]
  
  
  data_stat[,4] = as.numeric(gsub(",","",　data_stat[,4]　))
  data_stat[,5] = as.numeric(gsub(",","",　data_stat[,5]　))
  str(data_stat)
  
  data_stat$Gb = data_stat[,5]/(10^9)
  data_stat$Gb
  
  data_stat$c_fac = (0.3/data_stat$Gb)/2
  
  for(i in 1:length(N_pos) ){
    #assign( paste0( "_vcf_",N_pos[i],"_",SP[j]), 
    #      read.vcfR(paste0( "vcf/",N_pos[i],SP[j],".samtools.vcf" )) )
    
    assign( "vcf", 
            read.vcfR(paste0( "vcf/",SP[j],".",N_pos[i],".samtools.vcf" )) )
    
    # extract genotype data from vcf
    gt = extract.gt(vcf)
    #gt[1:10,]
    #dim(gt)
    # extract depyh data from vcf
    
    #ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
    #dp[1:10,]
    
    line_name = data_stat[,1]
    line_name = sub(paste0("merged_rawdata/",SP[j],"/"),"",line_name)
    line_name = sub(paste0("_1.fastq.gz"),"",line_name)
    line_name
    line_name = data.frame( strsplit(line_name, "_") )
    Unzip <- function(...) rbind(data.frame(), ...)
    line_name <- do.call(Unzip, line_name)
    data_stat = cbind(data_stat,line_name)
    line_name =  line_name[ N_pos[i] == line_name[,1]  ,2 ]
    
    
    dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
    dp[,1] =   dp[,1]*data_stat[data_stat[,11] == N_pos[i] & data_stat[,12] == line_name[1] ,][1,"c_fac"]
    dp[,2] =   dp[,2]*data_stat[data_stat[,11] == N_pos[i] & data_stat[,12] == line_name[2] ,][1,"c_fac"]
    
    
    
    
    
    # get marker information (chromosone numbers and positions)
    chrom <- getCHROM(vcf)
    pos <- getPOS(vcf)
    
    #show the first 10 SNPs of the first 10 lines 
    #gt[1:10, ]
    
    # create a matrix of gt scores
    gt.score <- matrix(NA, nrow(gt), ncol(gt))
    gt.score[gt == "0/0"] <- -1
    gt.score[gt == "0/1"] <- 0
    gt.score[gt == "1/1"] <- 1
    gt.score[gt == "0|0"] <- -1
    gt.score[gt == "0|1"] <- 0
    gt.score[gt == "1|1"] <- 1
    
    #gt.score[1:10,]
    #dim(gt.score)
    #str(gt.score)
    
    # name the rows and columns of matrix
    rownames(gt.score) <- rownames(gt)
    colnames(gt.score) <- colnames(gt)

    
    for(dp_limit in 1:20){
      
      all_data = FilterbyDP(dp_limit)
      #all_data[1:10,]
      dim(all_data)
      
      #extracted hoge% typing loci
      df = data.frame(all_data,stringsAsFactors = F)
      
      ####
      assign(paste0("df_",N_pos[i]),  df)
      
      if(hetero[j] == 0){
        df2 = df[  !is.na(df[,p1]) &
                     !is.na(df[,p2]) 
                   &  df[,p1] != 0  
                   &  df[,p2] != 0 
                   &  df[,p1] != df[,p2]
                   , ]
      }else {
        df2 = df[  !is.na(df[,p1]) &
                     !is.na(df[,p2]) 
                   &  df[,p1] != df[,p2]
                   , ]
      }
      
      #dp2 = apply(dp,1,mean)
      if(hetero[j] == 0){
        dp2 = dp[!is.na(df[,p1]) &
                   !is.na(df[,p2]) 
                 &  df[,p1] != 0  
                 &  df[,p2] != 0 
                 &  df[,p1] != df[,p2]
                 ,]
      }else{
        dp2 = dp[  !is.na(df[,p1]) &
                     !is.na(df[,p2]) 
                   &  df[,p1] != df[,p2]
                   , ]
      }
      
      assign( paste0(  "df2_",N_pos[i]  ) , df2)
      res_df[3*(dp_limit-1)+i,2]= nrow(df)
      res_df[3*(dp_limit-1)+i,3]= nrow(df2)
      res_df[3*(dp_limit-1)+i,4]= mean(dp2)
      res_df[3*(dp_limit-1)+i,5]= dp_limit
      res_df[3*(dp_limit-1)+i,6]= SP[j]
      
      if( dp_limit == 10){
        assign( paste0(  "MIG_",N_pos[i],"_",SP[j]  ) ,   paste0(df2$chrom,"_",df2$pos)  )
      }
      
      
    }
    
  } 
  
  assign( paste0("res_df_", SP[j] ) ,  res_df   )
  
  
}




############plot_data

library(ggpubr)

SP =      c("blueberry","capsicum","hexaploid_wheat","melon","peach","quinoa",
            "radish","rice","soy","tetraploid_wheat","tomato")
SP_list = c("Blueberry","Capsicum","Hexaploid wheat","Melon","Peach","Quinoa",
            "Radish", "Rice","Soy","Tetraploid wheat","Tomato")

for(j in 1:length(SP)){
  eval( parse(text=paste0("data = res_df_",SP[j]) ) )
  data[data=="m"] = "PS1"
  data[data=="m4n"] = "PS1_4"
  data[data=="m4n5n"] = "PS1_4-5"
  
  colnames(data) = c("Primer set name","Number of all SNPs","Number of common polymorphisms",
                     "DP","Threthold of DP","Species")
  gg = ggline(data, 
              x=  "Threthold of DP",
              y=  "Number of common polymorphisms",
              linetype = "Primer set name", shape ="Primer set name",
              color = "Primer set name", 
              title = SP_list[j]) #+ theme(legend.position="none")
  assign( paste0("gg",j) , gg)
  
  ggsave(gg,file= paste0(SP[j],"_dp_eva.pdf"),width=5,height=5 )
}

##############################
library(VennDiagram)

for(j in 1:length(SP)){
  spp = SP[j]
  eval(parse(text = paste0("bennlist= list(`PS1_4-5` = MIG_m4n5n_",spp,",
                          `PS1_4`   = MIG_m4n_",spp,",
                          `PS1`      = MIG_m_",spp,")")))
  venn.diagram(bennlist, filename=paste0(SP[j],".tiff"), 
               fill=c(4,3,2),
               width = 2000,height=2000)
}

