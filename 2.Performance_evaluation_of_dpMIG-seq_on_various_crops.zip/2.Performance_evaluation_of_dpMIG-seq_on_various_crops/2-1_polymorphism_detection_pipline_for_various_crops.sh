
####set working directory
mkdir merged_rawdata
mkdir stat
mkdir fastq
mkdir bam
mkdir sorted_bam
mkdir dp
mkdir vcf

#####blueberry
#####concatenate fastq files of same samples in each species


Primersets=(m m4n m4n5n)
Lines=(bb1 bb2)
SP=blueberry

####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1_1.fastq.gz rawdata/$SP/${PS}_${line}_2_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_1_2.fastq.gz rawdata/$SP/${PS}_${line}_2_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=20

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/V_corymbosum_genome_Draper_v1.hap1.fasta

####You need to run the following commented out script only once the first time
bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


#####capsicum
#####concatenate fastq files of same samples in each species
Primersets=(m m4n m4n5n)
Lines=(RH tkm)
SP=capsicum

####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1_1.fastq.gz rawdata/$SP/${PS}_${line}_2_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_1_2.fastq.gz rawdata/$SP/${PS}_${line}_2_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/Pepper.v.1.55.total.chr.fasta
echo $REF
####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done

#####hexaploid_wehat
#####concatenate fastq files of same samples in each species

Primersets=(m m4n m4n5n)
Lines=(jwc66 jwc96)
SP=hexaploid_wheat

####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1_1.fastq.gz rawdata/$SP/${PS}_${line}_2_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_1_2.fastq.gz rawdata/$SP/${PS}_${line}_2_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/iwgsc_refseqv2.0_all_chromosomes.fa
echo $REF

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


################
######melon#####
Primersets=(m m4n m4n5n)
Lines=(m3 mH)
SP=melon


####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1.fastq.gz  > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_2.fastq.gz  > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/CM3.6.1_pseudomol.fa


####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


################
######peach#####
Primersets=(m m4n m4n5n)
Lines=(pp7 pp9)
SP=peach


####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1_1.fastq.gz rawdata/$SP/${PS}_${line}_2_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_1_2.fastq.gz rawdata/$SP/${PS}_${line}_2_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/Prunus_persica_v2.0.a1.scaffolds.fasta

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


################
######quinoa#####
Primersets=(m m4n m4n5n)
Lines=(J027 J100)
SP=quinoa

####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${line}_1_${PS}_1.fastq.gz rawdata/$SP/${line}_2_${PS}_1.fastq.gz rawdata/$SP/${line}_3_${PS}_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${line}_1_${PS}_2.fastq.gz rawdata/$SP/${line}_2_${PS}_2.fastq.gz rawdata/$SP/${line}_3_${PS}_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/Cq_PI614886_genome_V1_pseudomolecule.fa

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done



################
######radish#####
Primersets=(m m4n m4n5n)
Lines=(rs5 rs6)
SP=radish

####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1_1.fastq.gz rawdata/$SP/${PS}_${line}_2_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_1_2.fastq.gz rawdata/$SP/${PS}_${line}_2_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done

####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~
REF=ref/$SP/GCF_000801105.1_Rs1.0_genomic.fa

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


################
######rice#####
Primersets=(m m4n m4n5n)
Lines=(Tk Tch)
SP=rice


####
mkdir merged_rawdata/$SP
cat rawdata/$SP/p1_1_1.fastq.gz rawdata/$SP/p1_2_1.fastq.gz rawdata/$SP/p1_3_1.fastq.gz > merged_rawdata/$SP/m4n5n_Tk_1.fastq.gz
cat rawdata/$SP/p1_1_2.fastq.gz rawdata/$SP/p1_2_2.fastq.gz rawdata/$SP/p1_3_2.fastq.gz > merged_rawdata/$SP/m4n5n_Tk_2.fastq.gz
cat rawdata/$SP/p2_1_1.fastq.gz rawdata/$SP/p2_2_1.fastq.gz rawdata/$SP/p2_3_1.fastq.gz > merged_rawdata/$SP/m4n5n_Tch_1.fastq.gz
cat rawdata/$SP/p2_1_2.fastq.gz rawdata/$SP/p2_2_2.fastq.gz rawdata/$SP/p2_3_2.fastq.gz > merged_rawdata/$SP/m4n5n_Tch_2.fastq.gz

cat rawdata/$SP/Tk_1_M_1.fastq.gz  rawdata/$SP/Tk_2_M_1.fastq.gz  > merged_rawdata/$SP/m_Tk_1.fastq.gz
cat rawdata/$SP/Tk_1_M_2.fastq.gz  rawdata/$SP/Tk_2_M_2.fastq.gz  > merged_rawdata/$SP/m_Tk_2.fastq.gz
cat rawdata/$SP/Tch_1_M_1.fastq.gz rawdata/$SP/Tch_2_M_1.fastq.gz > merged_rawdata/$SP/m_Tch_1.fastq.gz
cat rawdata/$SP/Tch_1_M_2.fastq.gz rawdata/$SP/Tch_2_M_2.fastq.gz > merged_rawdata/$SP/m_Tch_2.fastq.gz

cat rawdata/$SP/Tk_1_4N_1.fastq.gz  rawdata/$SP/Tk_2_4N_1.fastq.gz  > merged_rawdata/$SP/m4n_Tk_1.fastq.gz
cat rawdata/$SP/Tk_1_4N_2.fastq.gz  rawdata/$SP/Tk_2_4N_2.fastq.gz  > merged_rawdata/$SP/m4n_Tk_2.fastq.gz
cat rawdata/$SP/Tch_1_4N_1.fastq.gz rawdata/$SP/Tch_2_4N_1.fastq.gz > merged_rawdata/$SP/m4n_Tch_1.fastq.gz
cat rawdata/$SP/Tch_1_4N_2.fastq.gz rawdata/$SP/Tch_2_4N_2.fastq.gz > merged_rawdata/$SP/m4n_Tch_2.fastq.gz


####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~
REF=ref/$SP/IRGSP-1.0_genome.fasta

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


################
######soy#####
Primersets=(m m4n m4n5n)
Lines=(gm3 gm4)
SP=soy

####
mkdir merged_rawdata/$SP
cat rawdata/$SP/gm3_MIG_1.fastq.gz > merged_rawdata/$SP/m_gm3_1.fastq.gz
cat rawdata/$SP/gm3_MIG_2.fastq.gz > merged_rawdata/$SP/m_gm3_2.fastq.gz
cat rawdata/$SP/gm4_MIG_1.fastq.gz > merged_rawdata/$SP/m_gm4_1.fastq.gz
cat rawdata/$SP/gm4_MIG_2.fastq.gz > merged_rawdata/$SP/m_gm4_2.fastq.gz

cat rawdata/$SP/gm3_dpm_4N_1.fastq.gz > merged_rawdata/$SP/m4n_gm3_1.fastq.gz
cat rawdata/$SP/gm3_dpm_4N_2.fastq.gz > merged_rawdata/$SP/m4n_gm3_2.fastq.gz
cat rawdata/$SP/gm4_dpm_4N_1.fastq.gz > merged_rawdata/$SP/m4n_gm4_1.fastq.gz
cat rawdata/$SP/gm4_dpm_4N_2.fastq.gz > merged_rawdata/$SP/m4n_gm4_2.fastq.gz

cat rawdata/$SP/gm3_dpm_4_5N_1.fastq.gz > merged_rawdata/$SP/m4n5n_gm3_1.fastq.gz
cat rawdata/$SP/gm3_dpm_4_5N_2.fastq.gz > merged_rawdata/$SP/m4n5n_gm3_2.fastq.gz
cat rawdata/$SP/gm4_dpm_4_5N_1.fastq.gz > merged_rawdata/$SP/m4n5n_gm4_1.fastq.gz
cat rawdata/$SP/gm4_dpm_4_5N_2.fastq.gz > merged_rawdata/$SP/m4n5n_gm4_2.fastq.gz


####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~
REF=ref/$SP/Gmax_275_v2.0.fa

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done



################
######tetraploid_wheat#####
Primersets=(m m4n m4n5n)
Lines=(ldn st)
SP=tetraploid_wheat


####
mkdir merged_rawdata/$SP
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat rawdata/$SP/${PS}_${line}_1_1.fastq.gz rawdata/$SP/${PS}_${line}_2_1.fastq.gz > merged_rawdata/$SP/${PS}_${line}_1.fastq.gz
cat rawdata/$SP/${PS}_${line}_1_2.fastq.gz rawdata/$SP/${PS}_${line}_2_2.fastq.gz > merged_rawdata/$SP/${PS}_${line}_2.fastq.gz
done
done


####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/durum_genome.fasta

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done


################
######tomato#####
Primersets=(m m4n m4n5n)
Lines=(sl1 sl2)
SP=tomato


####
mkdir merged_rawdata/$SP
cat rawdata/$SP/m_sl1_1_1.fastq.gz  rawdata/$SP/m_sl1_2_1.fastq.gz  > merged_rawdata/$SP/m_sl1_1.fastq.gz
cat rawdata/$SP/m_sl1_1_2.fastq.gz  rawdata/$SP/m_sl1_2_2.fastq.gz  > merged_rawdata/$SP/m_sl1_2.fastq.gz
cat rawdata/$SP/m_sl2_1_1.fastq.gz  rawdata/$SP/m_sl2_2_1.fastq.gz  > merged_rawdata/$SP/m_sl2_1.fastq.gz
cat rawdata/$SP/m_sl2_1_2.fastq.gz  rawdata/$SP/m_sl2_2_2.fastq.gz  > merged_rawdata/$SP/m_sl2_2.fastq.gz

cat rawdata/$SP/sl1_1_4N_1.fastq.gz  rawdata/$SP/sl1_2_4N_1.fastq.gz  > merged_rawdata/$SP/m4n_sl1_1.fastq.gz
cat rawdata/$SP/sl1_1_4N_2.fastq.gz  rawdata/$SP/sl1_2_4N_2.fastq.gz  > merged_rawdata/$SP/m4n_sl1_2.fastq.gz
cat rawdata/$SP/sl2_1_4N_1.fastq.gz  rawdata/$SP/sl2_2_4N_1.fastq.gz  > merged_rawdata/$SP/m4n_sl2_1.fastq.gz
cat rawdata/$SP/sl2_1_4N_2.fastq.gz  rawdata/$SP/sl2_2_4N_2.fastq.gz  > merged_rawdata/$SP/m4n_sl2_2.fastq.gz

cat rawdata/$SP/sl1_1_4_5N_1.fastq.gz  rawdata/$SP/sl1_2_4_5N_1.fastq.gz  > merged_rawdata/$SP/m4n5n_sl1_1.fastq.gz
cat rawdata/$SP/sl1_1_4_5N_2.fastq.gz  rawdata/$SP/sl1_2_4_5N_2.fastq.gz  > merged_rawdata/$SP/m4n5n_sl1_2.fastq.gz
cat rawdata/$SP/sl2_1_4_5N_1.fastq.gz  rawdata/$SP/sl2_2_4_5N_1.fastq.gz  > merged_rawdata/$SP/m4n5n_sl2_1.fastq.gz
cat rawdata/$SP/sl2_1_4_5N_2.fastq.gz  rawdata/$SP/sl2_2_4_5N_2.fastq.gz  > merged_rawdata/$SP/m4n5n_sl2_2.fastq.gz


####
seqkit stat merged_rawdata/$SP/*fastq.gz > stat/stat_$SP.txt

###Trimmomatic
mkdir fastq/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
trimmomatic PE -threads 4 -phred33  merged_rawdata/$SP/${PS}_${line}_1.fastq.gz merged_rawdata/$SP/${PS}_${line}_2.fastq.gz \
fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_unpaired_output_1.fq \
fastq/$SP/${line}_${PS}_paired_output_2.fq fastq/$SP/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
#fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
#fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq
done
done

####Set num of threads
thread=4

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/$SP/tomato_ref.fasta

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
mkdir bam/$SP
mkdir dp/$SP

for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/$SP/${line}_${PS}_paired_output_1.fq fastq/$SP/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/$SP/${line}_${PS}.bam
samtools sort -@ $thread -o bam/$SP/${line}_${PS}.sorted.bam bam/$SP/${line}_${PS}.bam
samtools index -@ $thread bam/$SP/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/$SP/${line}_${PS}.sorted.bam > dp/$SP/${line}_${PS}_dp_output
rm bam/$SP/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done


for PS in ${Primersets[@]}; do
 samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/$SP/*${PS}.sorted.bam\
  | bcftools call -c -v -o vcf/$SP.${PS}.samtools.vcf
done
