
####set working directory

####Make directory
mkdir bam
mkdir vcf
mkdir fastq
mkdir reports
mkdir reports_trim
mkdir dp

####Make list of primer set names
Primersets=(MIG 10N 14N 3N 3_4N 3_5N \
4N 4_6N 4_7N 4_5N \
4_8N 4_9N 5N 7N cm4N cm4_5N cm)
Lines=(sl1 sl2)

####Merge replicates]
cd rawdata
mkdir merged_data
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
cat ${line}_1_${PS}_1.fastq.gz ${line}_2_${PS}_1.fastq.gz > merged_data/${line}_${PS}_1.fastq.gz
cat ${line}_1_${PS}_2.fastq.gz ${line}_2_${PS}_2.fastq.gz > merged_data/${line}_${PS}_2.fastq.gz
done
done
cd ../


####
seqkit stat rawdata/merged_data/*.fastq.gz > stat.tsv


####trimmomaticでトリミング
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do

trimmomatic PE -threads 4 -phred33  rawdata/merged_data/${line}_${PS}_1.fastq.gz rawdata/merged_data/${line}_${PS}_2.fastq.gz \
fastq/${line}_${PS}_paired_output_1.fq fastq/${line}_${PS}_unpaired_output_1.fq \
fastq/${line}_${PS}_paired_output_2.fq fastq/${line}_${PS}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15

fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_1.fastq.gz
fastqc --nogroup -o ./reports rawdata/merged_data/${line}_${PS}_2.fastq.gz

fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_1.fq
fastqc --nogroup -o ./reports_trim fastq/${line}_${PS}_paired_output_2.fq

done
done


cd reports
multiqc .
cd ../

cd reports_trim
multiqc .
cd ../


####Set num of threads
thread=10

####Set path for refference genome
##This reference genome was downloaded from ~.
REF=ref/tomato/tomato_ref.fasta

####You need to run the following commented out script only once the first time
#bwa index -p $REF $REF
#samtools faidx $REF

##Reads were mapped and depth are being conducted.
for line in ${Lines[@]}; do
for PS in ${Primersets[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${line}_${PS}\tPL:illumina\tLB:${line}_${PS}_library_1" -t $thread -M -o ${line}_${PS}.sam \
$REF fastq/${line}_${PS}_paired_output_1.fq fastq/${line}_${PS}_paired_output_2.fq
samtools view -@ $thread -bS ${line}_${PS}.sam > bam/${line}_${PS}.bam
samtools sort -@ $thread -o bam/${line}_${PS}.sorted.bam bam/${line}_${PS}.bam
samtools index -@ $thread bam/${line}_${PS}.sorted.bam
samtools depth -d 0  bam/${line}_${PS}.sorted.bam > dp/${line}_${PS}_dp_output

rm bam/${line}_${PS}.bam
rm ${line}_${PS}.sam
done
done

###Variant call by samtools mpileup
for PS in ${Primersets[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/sl1_${PS}.sorted.bam bam/sl2_${PS}.sorted.bam \
 | bcftools call -c -v -o vcf/${PS}_samtools.vcf
 vcftools --vcf vcf/${PS}_samtools.vcf --max-missing 1 --minDP 1 \
 --recode --recode-INFO-all --out vcf/filtered_${PS}_samtools.vcf
done
