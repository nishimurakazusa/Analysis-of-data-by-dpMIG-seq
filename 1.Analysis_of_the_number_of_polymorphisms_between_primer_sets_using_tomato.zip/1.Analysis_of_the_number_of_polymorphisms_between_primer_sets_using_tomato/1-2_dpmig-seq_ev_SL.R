
require(vcfR)
#filtering by depth
#set parameter
#b =10
FilterbyDP = function(b){
  
  filter_dp_progeny = b
  
  dp_pro = dp
  colnames(dp_pro)
  
  gt.score_pro = gt.score
  
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  
  gt.score_filtered = gt.score_pro
  
  all_data = data.frame(chrom,pos,gt.score_filtered)
  
  str(all_data)
  
  return(all_data)
}


# read compressed vcf file (*.vcf.gz)
N_pos = c("10N", "14N", "3N", "3_4N", "3_5N", 
           "4N", "4_6N", "4_7N", "4_5N", 
         "4_8N", "4_9N", "5N", "7N", "cm4N", "cm4_5N", "cm", "MIG")
i=1
data_stat =  read.table(file="stat.tsv",header=T)
data_stat = data_stat[seq(1,nrow(data_stat),by=2),]
str(data_stat)
s<-sub(",","",data_stat$num_seqs)
s<-sub(",","",s)
as.numeric(s)

data_stat$Gb = as.numeric(s)*151/(10^9)
data_stat$Gb
data_stat$c_fac = 0.3/data_stat$Gb

data_stat
file_names<-sub("rawdata/merged_data/","",data_stat$file)
file_names<-sub("_1.fastq.gz","",file_names)
data_stat$line_ps = file_names

#i=1
dp_limit = 10

p1=1+2
p2=2+2
res_df= data.frame(matrix(NA, nrow = length(N_pos), ncol = 4))
res_df[,1] =N_pos 

for(i in 1:length(N_pos) ){
 
  assign( paste0("vcf_",N_pos[i]), 
          read.vcfR(paste0( "vcf/filtered_",N_pos[i],"_samtools.vcf.recode.vcf" )) )
  assign( "vcf", 
          read.vcfR(paste0( "vcf/filtered_",N_pos[i],"_samtools.vcf.recode.vcf" )) )
  
  # extract genotype data from vcf
  gt = extract.gt(vcf)
  #gt[1:10,]
  #dim(gt)
  # extract depyh data from vcf
  dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
  ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
  #dp[1:10,]
  
  dp[,1] =   dp[,1]*data_stat$c_fac[ data_stat$line_ps == paste0("sl1_",N_pos[i])]
  dp[,2] =   dp[,2]*data_stat$c_fac[ data_stat$line_ps == paste0("sl2_",N_pos[i])]
  
  
  # get marker information (chromosone numbers and positions)
  chrom <- getCHROM(vcf)
  pos <- getPOS(vcf)
  
  #show the first 10 SNPs of the first 10 lines 
  #gt[1:10, ]
  
  # create a matrix of gt scores
  gt.score <- matrix(NA, nrow(gt), ncol(gt))
  gt.score[gt == "0/0"] <- -1
  gt.score[gt == "0/1"] <- 0
  gt.score[gt == "1/1"] <- 1
  gt.score[gt == "0|0"] <- -1
  gt.score[gt == "0|1"] <- 0
  gt.score[gt == "1|1"] <- 1
  
  #gt.score[1:10,]
  #dim(gt.score)
  #str(gt.score)
  
  # name the rows and columns of matrix
  rownames(gt.score) <- rownames(gt)
  colnames(gt.score) <- colnames(gt)
  #gt.score[1:10, 1]
  
  #hist(dp)
  dp_sum = apply(dp,1,sum)
  #length(dp_sum)
  #length(pos)
  #length(chrom)
  
  #############Filtering by DP
  all_data = FilterbyDP(dp_limit)
  #all_data[1:10,]
  dim(all_data)
  
  #extracted hoge% typing loci
  df = data.frame(all_data,stringsAsFactors = F)
  
  ####
  assign(paste0("df_",N_pos[i]),  df)

  df2 = df[  !is.na(df[,p1]) &
               !is.na(df[,p2]) 
             &  df[,p1] != 0  
             &  df[,p2] != 0 
             &  df[,p1] != df[,p2]
             , ]
  
  dp2 = apply(dp,1,mean)
  dp2 = dp[!is.na(df[,p1]) &
             !is.na(df[,p2]) 
           &  df[,p1] != 0  
           &  df[,p2] != 0 
           &  df[,p1] != df[,p2]
           ,]

  assign( paste0(  "df2_",N_pos[i]  ) , df2)
  res_df[i,2]= nrow(df)
  res_df[i,3]= nrow(df2)
  res_df[i,4]= mean(dp2)
  assign( paste0(  "MIG_",N_pos[i]  ) ,   paste0(df2$chrom,"_",df2$pos)  )
  
  } 

res_df
colnames(res_df) = c("Primer","Number of raw SNP","Polymorphisms","Average_DP")
res_df$`Polymorphism rate` = res_df$Polymorphisms/res_df$`Number of raw SNP`*100
res_df$`Ratio to MIGseq`= res_df$Polymorphisms/res_df[17,3]

res_df2 = res_df[c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15)  , ]
res_df2
write.csv(res_df2 ,file="res_df.csv")

plot(res_df2[,2:5])
rownames(res_df2) = 1:17

library(ggsci)
library(ggplot2)

#########
data = res_df2
data[,1] = c("PS1","PS1_3","PS1_4","PS1_5","PS1_7","PS1_10","PS1_14",
             "PS1_3-4","PS1_3-5","PS1_4-5","PS1_4-6","PS1_4-7","PS1_4-8","PS1_4-9",
             "PS2","PS2_4","PS2_4-5" )

data[,1] = factor(data$Primer,levels=data$Primer)
colnames(data)[6] = c("Ratio of the number of polymorphisms detected by each primer set to PS1")
colnames(data)[3] = "Number of polymorphisms"
colnames(data)[1] = "Primer set name" 
str(data)
g <- ggplot(data, aes(x = `Primer set name`, y = `Number of polymorphisms` , fill = `Primer set name`))
g <- g + geom_bar(stat = "identity") +theme_classic()
g= g+   geom_text(aes(x = `Primer set name`, y = `Number of polymorphisms`,  
                      label = `Number of polymorphisms`, vjust = -0.5,
              group = `Primer set name`), 
              position = position_dodge(width = 0.9))

#g <- g + scale_fill_nejm()
plot(g)
ggsave(g,file="Fig_1c.pdf",height=5,width=12)





###########Drawing a Venn diagram
library(VennDiagram)
dir.create("venn_diagram")
j=1
i=5
for(j in 1:length(N_pos)){
  for(i in 1:length(N_pos) ){

    message(paste0(N_pos[i]," ",N_pos[j]))
    eval(parse(text= paste0("x = MIG_",N_pos[i])))
    eval(parse(text= paste0("y = MIG_",N_pos[j])))
    data=list(y = y, x = x ) 
    names(data)[2] = paste0("MIG_",N_pos[i])
    names(data)[1] = paste0("MIG_",N_pos[j])
    venn.diagram(data,filename=paste0("venn_diagram/List_",N_pos[j],"_",N_pos[i],"_",dp_limit,".tiff"), 
                 fill=c(5,6), lty=c(1,3), scaled=T, 
                 height = 3000, width = 3000)
  
    
  }
}

############
res_df_SNP = data.frame(matrix(NA,nrow=17,ncol=17)  )
rownames(res_df_SNP) = N_pos
colnames(res_df_SNP) = N_pos

for(j in 1:length(N_pos)){
  for(i in 1:length(N_pos)){
    message(paste0(N_pos[i],"",N_pos[j]))
    eval(parse(text= paste0("x = MIG_",N_pos[i])))
    eval(parse(text= paste0("y = MIG_",N_pos[j])))
    res_df_SNP[i,j] <- length(intersect(x, y))/length(unique(c(x,y)))
  }
}

res_df_SNP2 = res_df_SNP[c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15), ]
res_df_SNP3 = res_df_SNP2[,c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15)]

write.csv(res_df_SNP3, file="res_df_SNP.csv")


############################
data = res_df2
data$Primer = c("Control","3","4","5","7","10","14",
                "3-4","3-5",
                "4-5","4-6","4-7","4-8","4-9",
                "N","N 4","N 4-5")

data$Primer = factor(data$Primer,levels=data$Primer)
colnames(data)[6] = "Ratio to MIG-seq"
str(data)
g <- ggplot(data, aes(x = Primer, y = `Ratio to MIG-seq` , fill = Primer))
g <- g + geom_bar(stat = "identity")
#g <- g + scale_fill_nejm()
g = g + theme_classic()
ggsave(g,file="res_MIG_ratio.pdf",height=5,width=10)
data$Polymorphisms

g <- ggplot(data, aes(x = Primer, y = `Polymorphisms` , fill = Primer))
g <- g + geom_bar(stat = "identity")
g = g + theme_classic()
#g <- g + scale_fill_nejm()
plot(g)
ggsave(g,file="res_MIG_SNPnumber.pdf",height=5,width=10)


##########################
res_df_SNP2 = res_df_SNP[c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15), ]
res_df_SNP3 = res_df_SNP2[,c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15)]

write.csv(res_df_SNP3, file="res_df_SNP.csv")


rownames(res_df_SNP3) = c("01_PS1","02_PS1_3","03_PS1_4","04_PS1_5","05_PS1_7","06_PS1_10","07_PS1_14",
                          "08_PS1_3-4","09_PS1_3-5","10_PS1_4-5","11_PS1_4-6","12_PS1_4-7","13_PS1_4-8","14_PS1_4-9",
                          "15_PS2","16_PS2_4","17_PS2_4-5" )
colnames(res_df_SNP3) = c("01_PS1","02_PS1_3","03_PS1_4","04_PS1_5","05_PS1_7","06_PS1_10","07_PS1_14",
                          "08_PS1_3-4","09_PS1_3-5","10_PS1_4-5","11_PS1_4-6","12_PS1_4-7","13_PS1_4-8","14_PS1_4-9",
                          "15_PS2","16_PS2_4","17_PS2_4-5" )

res_df_SNP3

library(tidyverse)


res_df_SNP4 = res_df_SNP3*100
df <- data.frame(res_df_SNP4) %>% 
tibble::rownames_to_column(var = "Primer X")

df.long <- pivot_longer(df, 
                        cols = -c("Primer X"),
                        names_to = "Primer Y", 
                        values_to = "Rate")


2
gg_h= ggplot(df.long, aes(x = `Primer X`, y = `Primer Y`, fill = Rate)) + 
geom_tile(color = "white") + 
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(0, 100), 
                       name = "Rate (%)", space = "Lab",
                       na.value = "white")+
  geom_text(aes(label = ifelse(is.na(Rate) | Rate %in% "",NA, sprintf("%0.2f", Rate))),
            color = "black", size = 2.5)+
  theme_classic()+ 
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

gg_h

ggsave(gg_h, file="Fig_1d_Heatmap.pdf", height=8, width=8)




