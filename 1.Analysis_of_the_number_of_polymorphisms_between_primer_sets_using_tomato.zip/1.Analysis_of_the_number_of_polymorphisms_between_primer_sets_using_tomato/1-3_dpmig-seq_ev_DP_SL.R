
N_pos = c("10N", "14N", "3N", "3_4N", "3_5N", 
           "4N", "4_6N", "4_7N", "4_5N", 
         "4_8N", "4_9N", "5N", "7N", "cm4N", "cm4_5N", "cm", "MIG")
i=1
dir.create("depth_res")


data_stat =  read.table(file="stat.tsv",header=T)
data_stat = data_stat[seq(1,nrow(data_stat),by=2),]
str(data_stat)
s<-sub(",","",data_stat$num_seqs)
s<-sub(",","",s)
as.numeric(s)

data_stat$Gb = as.numeric(s)*151/(10^9)
data_stat$Gb
data_stat$c_fac = 0.3/data_stat$Gb

data_stat
file_names<-sub("rawdata/merged_data/","",data_stat$file)
file_names<-sub("_1.fastq.gz","",file_names)
data_stat$line_ps = file_names


i=1
res_df= data.frame(matrix(NA, nrow = length(N_pos), ncol = 5))
res_df[,1] =N_pos 

for(i in 1:length(N_pos) ){
 
  message(paste0(N_pos[i]))
  dp_sl1 = read.table( file = paste0("dp/sl1_",N_pos[i],"_dp_output") )
  dp_sl2 = read.table( file = paste0("dp/sl2_",N_pos[i],"_dp_output") )
  
  dp_sl1[,3] =   dp_sl1[,3]*data_stat$c_fac[ data_stat$line_ps == paste0("sl1_",N_pos[i])]
  dp_sl2[,3] =   dp_sl2[,3]*data_stat$c_fac[ data_stat$line_ps == paste0("sl2_",N_pos[i])]
  
  dp_sl1 = dp_sl1[dp_sl1[,3]>=10, ]
  dp_sl2 = dp_sl2[dp_sl2[,3]>=10, ]
  
  dp_sl1_chrpos = paste0(dp_sl1[,1],"_",dp_sl1[,2])
  dp_sl2_chrpos = paste0(dp_sl2[,1],"_",dp_sl2[,2])
  
  res_df[i,2]= length(union(dp_sl1_chrpos, dp_sl2_chrpos ) )
  res_df[i,3]= length(intersect(dp_sl1_chrpos, dp_sl2_chrpos ) )
  res_df[i,4]= sum(dp_sl1[,3])
  res_df[i,5]= sum(dp_sl2[,3])
  assign( paste0(  "MIG_",N_pos[i]  ) ,   intersect(dp_sl1_chrpos, dp_sl2_chrpos )  )
} 

res_df
colnames(res_df) = c("Primer","number_of_mapped_bases","common_mapped_bases","Sum_dp_sl1","Sum_dp_sl2")
res_df$`Polymorphism rate` = res_df$common_mapped_bases/res_df$number_of_mapped_bases*100
res_df$`Ratio to MIGseq`= res_df$common_mapped_bases/res_df[17,3]

res_df2 = res_df[c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15)  , ]
res_df2
write.csv(res_df2 ,file="depth_res/res_df.csv")

plot(res_df2[,2:5])
rownames(res_df2) = 1:17

library(ggsci)
library(ggplot2)


###
data = res_df2[1:7,]
data$Primer = factor(data$Primer,levels=data$Primer)
str(data)
g <- ggplot(data, aes(x = Primer, y = `Ratio to MIGseq` , fill = Primer))
g <- g + geom_bar(stat = "identity")
#g <- g + scale_fill_nejm()
plot(g)


###
data = res_df2[c(1,10:14,2,8:9),]
data$Primer = factor(data$Primer,levels=data$Primer)
str(data)
g <- ggplot(data, aes(x = Primer, y = `Ratio to MIGseq` , fill = Primer))
g <- g + geom_bar(stat = "identity")
#g <- g + scale_fill_nejm()
plot(g)


###
data = res_df2[c(1,15:17),]
data$Primer = factor(data$Primer,levels=data$Primer)
str(data)
g <- ggplot(data, aes(x = Primer, y = `Ratio to MIGseq` , fill = Primer))
g <- g + geom_bar(stat = "identity")
#g <- g + scale_fill_nejm()
plot(g)


###
data = res_df2
data[,1] = c("PS1","PS1_3","PS1_4","PS1_5","PS1_7","PS1_10","PS1_14",
             "PS1_3-4","PS1_3-5","PS1_4-5","PS1_4-6","PS1_4-7","PS1_4-8","PS1_4-9",
             "PS2","PS2_4","PS2_4-5" )

data[,1] = factor(data$Primer,levels=data$Primer)
colnames(data)[8] = c("Ratio of the number of polymorphisms detected by each primer set to PS1")
colnames(data)[3] = "Mapped bases"
colnames(data)[1] = "Primer set name" 
str(data)
g <- ggplot(data, aes(x = `Primer set name`, y = `Mapped bases` , fill = `Primer set name`))
g <- g + geom_bar(stat = "identity") +theme_classic()
g= g+   geom_text(aes(x = `Primer set name`, y = `Mapped bases`,  
                      label = `Mapped bases`, vjust = -0.5,
              group = `Primer set name`), # 
              position = position_dodge(width = 0.9))#

#g <- g + scale_fill_nejm()
plot(g)
ggsave(g,file="depth_res/res_MIG_dpMIG_number_of_bases.pdf",height=5,width=12)


###########
library(VennDiagram)
###### Draw a Venn diagram
for(j in 1:length(N_pos)){
  for(i in 1:length(N_pos) ){
    message(paste0(N_pos[i]," ",N_pos[j]))
    eval(parse(text= paste0("x = MIG_",N_pos[i])))
    eval(parse(text= paste0("y = MIG_",N_pos[j])))
    data=list(y = y, x = x ) 
    names(data)[2] = paste0("MIG_",N_pos[i])
    names(data)[1] = paste0("MIG_",N_pos[j])
    venn.diagram(data,filename=paste0("depth_res/List_",N_pos[j],"_",N_pos[i],"_",dp_limit,".tiff"), 
                 fill=c(2,3), alpha=0.4, lty=2,
                 height = 5000, width = 5000)
  }
}

##
res_df_SNP = data.frame(matrix(NA,nrow=17,ncol=17)  )
rownames(res_df_SNP) = N_pos
colnames(res_df_SNP) = N_pos

for(j in 1:length(N_pos)){
  for(i in 1:length(N_pos)){
    message(paste0(N_pos[i]," ",N_pos[j]))
    eval(parse(text= paste0("x = MIG_",N_pos[i])))
    eval(parse(text= paste0("y = MIG_",N_pos[j])))
    res_df_SNP[i,j] <- length(intersect(x, y))/length(unique(c(x,y)))
  }
}

res_df_SNP2 = res_df_SNP[c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15), ]
res_df_SNP3 = res_df_SNP2[,c(17,3,6,12,13,1,2,4,5,9,7,8,10,11,16,14,15)]

write.csv(res_df_SNP3, file="depth_res/res_df_number_of_bases.csv")

#######
data = res_df2
data$Primer = c("Control","3","4","5","7","10","14",
                "3-4","3-5",
                "4-5","4-6","4-7","4-8","4-9",
                "N","N 4","N 4-5")

data$Primer = factor(data$Primer,levels=data$Primer)
colnames(data)[6] = "Ratio to MIG-seq"
str(data)
g <- ggplot(data, aes(x = Primer, y = `Ratio to MIG-seq` , fill = Primer))
g <- g + geom_bar(stat = "identity")
#g <- g + scale_fill_nejm()
g = g + theme_classic()
plot(g)
ggsave(g,file="depth_res/res_ratio.pdf",height=5,width=10)
data$Polymorphisms

g <- ggplot(data, aes(x = Primer, y = `Polymorphisms` , fill = Primer))
g <- g + geom_bar(stat = "identity")
g = g + theme_classic()
#g <- g + scale_fill_nejm()
plot(g)
ggsave(g,file="depth_res/res_MIG_number_of_bases.pdf",height=5,width=10)
