
mkdir bam
mkdir vcf
mkdir fastq
mkdir reports

cd rawdata
SEQLIBS=$(echo $(ls *_1.fastq.gz| sed 's/\_[^\_]*$//'| tr '\n' ' '))
cd ..
echo $SEQLIBS

cd rawdata
cat MG1_1_1.fastq.gz MG1_2_1.fastq.gz MG1_3_1.fastq.gz MG1_4_1.fastq.gz MG2_1_1.fastq.gz MG2_2_1.fastq.gz MG2_3_1.fastq.gz > MG_1.fastq.gz
cat MG1_1_2.fastq.gz MG1_2_2.fastq.gz MG1_3_2.fastq.gz MG1_4_2.fastq.gz MG2_1_2.fastq.gz MG2_2_2.fastq.gz MG2_3_2.fastq.gz > MG_2.fastq.gz
cat MS1_1_1.fastq.gz MS1_2_1.fastq.gz MS1_3_1.fastq.gz MS1_4_1.fastq.gz MS3_1_1.fastq.gz > MS_1.fastq.gz
cat MS1_1_2.fastq.gz MS1_2_2.fastq.gz MS1_3_2.fastq.gz MS1_4_2.fastq.gz MS3_1_2.fastq.gz > MS_2.fastq.gz
cd ..

SEQLIBS=(MG MS R001 R002 R004 R005 R006 R007 R010 R012 R013 R015 R017 \
R019 R020 R021 R022 R023 R024 R027 R029 R034 R035 R038 R040 R044 \
R045 R047 R048 R050 R052 R055 R060 R061 R062 R064 R065 R066 R067 \
R068 R069 R073 R075 R079 R080 R081 R082 R083 R085 R087 R088 R092 \
R095 R097 R101 R102 R103 R105 R106 R108 R109 R112 R114 R116 R117 \
R119 R120 R122 R123 R125 R127 R128 R130 R133 R134 R136 R137 R139 \
R140 R141 R142 R145 R146 R147 R148 R152 R153 R155 R156 R157 R159 \
R162 R163 R168 R169 R170 R171 R172 R173 R174 R177 R178 R179 R181 \
R182 R183 R184 R187 R189 R190 R192 R193 R195 R196 R6-005 R6-007 \
R6-008 R6-011 R6-018 R6-019 R6-020 R6-030 R6-032)


REF=../ref/soy/Gmax_275_v2.0.fa

for seqlib in ${SEQLIBS[@]}; do
fastp -i rawdata/${seqlib}_1.fastq.gz -I rawdata/${seqlib}_2.fastq.gz -3 \
 -o fastq/${seqlib}.1.fastq.gz -O fastq/${seqlib}.2.fastq.gz\
 -h ${seqlib}.report.html -j ${seqlib}.report.json -q 20 -n 10 -f 17 -F 17
done
mv *report.html reports
mv *report.json reports


mkdir bam2
thread=20
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}.1.fastq.gz fastq/${seqlib}.2.fastq.gz
samtools view -@ $thread -bS ${seqlib}.sam > bam2/${seqlib}.bam
samtools sort -@ $thread -o bam2/${seqlib}.sorted.bam bam2/${seqlib}.bam
samtools index -@ $thread -c bam2/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam2/${seqlib}.bam
done
###
samtools mpileup -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam2/*.sorted.bam \
 | bcftools call -c -v -o dpMIG_bwa_soy_mori_F2_samtools.vcf

##
vcftools --vcf dpMIG_bwa_soy_mori_F2_samtools.vcf --max-missing 0.5 --minDP 5 --max-alleles 2 --min-alleles 2 --maf 0.10  \
--recode --recode-INFO-all --out filtered_dpMIG_bwa_soy_mori_F2_samtools.vcf


####
####
CHRS=(Chr01 Chr02 Chr03 Chr04 Chr05 Chr06 Chr07 Chr08 Chr09 Chr10 \
Chr11 Chr12 Chr13 Chr14 Chr15 Chr16 Chr17 Chr18 Chr19 Chr20)
for chr in ${CHRS[@]}; do
mkdir ${chr}
vcftools --vcf filtered_dpMIG_bwa_soy_mori_F2_samtools.vcf.recode.vcf --max-missing 0.8 --chr ${chr} --maf 0.25 \
--recode --recode-INFO-all --out ${chr}/${chr}.samtools.vcf
java -cp Lep-MAP3/bin ParentCall2 data = pedigree.txt  vcfFile = ${chr}/${chr}.samtools.vcf.recode.vcf > ${chr}/p.call
java -cp Lep-MAP3/bin Filtering2 data=${chr}/p.call \
 heterozygoteRate=00000.1 removeNonInformative=1 dataTolerance=0.000001  > ${chr}/p_fil.call
java -cp Lep-MAP3/bin  SeparateChromosomes2 data=${chr}/p_fil.call distortionLod=1 lodLimit=3 theta =0.05 numThreads=6 > ${chr}/map.txt
sort ${chr}/map.txt|uniq -c|sort -n
done

CHRS=(Chr06 Chr08 Chr15 Chr17)
for chr in ${CHRS[@]}; do
mkdir ${chr}
vcftools --vcf filtered_dpMIG_bwa_soy_mori_F2_samtools.vcf.recode.vcf --max-missing 0.8 --chr ${chr} \
--recode --recode-INFO-all --out ${chr}/${chr}.samtools.vcf
java -cp Lep-MAP3/bin ParentCall2 data = pedigree.txt  vcfFile = ${chr}/${chr}.samtools.vcf.recode.vcf > ${chr}/p.call
java -cp Lep-MAP3/bin Filtering2 data=${chr}/p.call \
 heterozygoteRate=00000.1 removeNonInformative=1 dataTolerance=0.000001  > ${chr}/p_fil.call
java -cp Lep-MAP3/bin  SeparateChromosomes2 data=${chr}/p_fil.call distortionLod=1 lodLimit=3 theta=0.2 numThreads=6 > ${chr}/map.txt
sort ${chr}/map.txt|uniq -c|sort -n
done


CHRS=(Chr01 Chr02 Chr03 Chr04 Chr05 Chr06 Chr07 Chr08 Chr09 Chr10 \
Chr11 Chr12 Chr13 Chr14 Chr15 Chr16 Chr17 Chr18 Chr19 Chr20)
for chr in ${CHRS[@]}; do
java -cp Lep-MAP3/bin OrderMarkers2 data=${chr}/p_fil.call map=${chr}/map.txt sexAveraged=1 \
grandparentPhase=1 numThreads=6 outputPhasedData=1  > ${chr}/order.txt
#java -cp $PA/Lep-MAP3/bin  OrderMarkers2 evaluateOrder=${chr}/order.txt data=${chr}/p_fil.call improveOrder=0 sexAveraged=1 > ${chr}/order1.SA.txt
cut -f1,2 ${chr}/p_fil.call > ${chr}/cut_p_fil.call.txt
awk -v fullData=1 -f map2genotypes.awk ${chr}/order.txt > ${chr}/genotypes.${chr}.txt
done
