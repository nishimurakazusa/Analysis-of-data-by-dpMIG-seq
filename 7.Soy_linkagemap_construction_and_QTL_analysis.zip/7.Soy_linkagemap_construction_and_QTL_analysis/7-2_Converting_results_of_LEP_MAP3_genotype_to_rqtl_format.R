

chr_list = c("Chr01","Chr02","Chr03","Chr04","Chr05", 
             "Chr06","Chr07","Chr08","Chr09","Chr10",
             "Chr11","Chr12","Chr13","Chr14","Chr15", 
             "Chr16","Chr17","Chr18","Chr19","Chr20")


inverse_list = c(2,4,5,7,9,10,11,14,16,17,18)


i = 1
i = 4
dir.create("genodata")

for(i in 1:length(chr_list)){
###
marker_name = read.table(file=paste0(chr_list[i],"/cut_p_fil.call.txt"), skip=7)
genotype_table = read.table(file=paste0(chr_list[i],"/genotypes.",chr_list[i],".txt"),
                            sep="\t")
colnames(genotype_table) = genotype_table[2,]
genotype_table = genotype_table[c(7:nrow(genotype_table)),]

genotype_table[genotype_table == "1 1"] =  "A" 
genotype_table[genotype_table == "1 2"] =  "H"
genotype_table[genotype_table == "2 1"] =  "H"
genotype_table[genotype_table == "2 2"] =  "B"
#genotype_table[genotype_table == "0 0"] =  "-"

for(j in as.numeric(genotype_table$MARKER) ){
genotype_table[genotype_table$MARKER == j,1] = paste0(marker_name[j,1],"_",marker_name[j,2] )
}


pos = as.numeric(genotype_table$MALE_POS) 
pos_c= which( pos - c(0,pos[1:(length(pos)-1)])   <   0   ) - 1
pos_c = c(pos_c,nrow(genotype_table))

if(length(pos_c) >= 2){
pos_c =  c(pos_c[1],  (pos_c[2:length(pos_c)] - pos_c[1:(length(pos_c)-1)]) )
}

#k=1
chr_num = 0
for(k in 1:(length(pos_c)) ){
chr_num= c(chr_num ,   rep(paste0(chr_list[i],"_", k) , pos_c[k] )  )
}


###
genotype_table$CHR = chr_num[-1]
write.csv(genotype_table,file=paste0( "genodata/map_geno_",chr_list[i],".csv")) 
}


####Integrating genotypes
genotype_table_all = read.csv(file=paste0( "genodata/map_geno_",chr_list[1],".csv"),
         row.names = 1,header = T,stringsAsFactors = F
         ) 
for(i in 2:20){
genotype_table_all = rbind(genotype_table_all,
  read.csv(file=paste0( "genodata/map_geno_",chr_list[i],".csv"),
                                row.names = 1,header = T,stringsAsFactors = F
  ) 
)
}

#######
write.csv(genotype_table_all,file="genotype_table_all.csv")


chr_names = names(table(genotype_table_all$CHR))[table(genotype_table_all$CHR) <40]
chr_names2 = names(table(genotype_table_all$CHR))[table(genotype_table_all$CHR) >=40]
chr_names2

genotype_table_for_qtl = genotype_table_all

chr_names
i=1
for(i in 1:length(chr_names)){ 
  genotype_table_for_qtl[genotype_table_all$CHR == chr_names[i], 2] = 0
}
genotype_table_for_qtl = genotype_table_for_qtl[genotype_table_for_qtl$CHR != 0,]
genotype_table_for_qtl = genotype_table_for_qtl[,c(1,2,3,7:ncol(genotype_table_for_qtl))]
colnames(genotype_table_for_qtl)[1:3] = c("id","","")
colnames(genotype_table_for_qtl)[4:ncol(genotype_table_for_qtl)] = 1:(ncol(genotype_table_for_qtl)-3)
genotype_table_for_qtl

i=1

for(i in inverse_list){
  x= genotype_table_for_qtl[ genotype_table_for_qtl[,2] == chr_names2[i], ]
  x[,3] = max(x[,3])- x[,3]
  message(paste0(x[1:10,1]))
  genotype_table_for_qtl[ genotype_table_for_qtl[,2] == chr_names2[i], ] = x[nrow(x):1,]
  }



pos_dif= c(genotype_table_for_qtl[2:nrow(genotype_table_for_qtl),3],0) - genotype_table_for_qtl[,3]
hist(pos_dif)

dup1= which(genotype_table_for_qtl$id == "Chr04_8718000")
dup2= which(genotype_table_for_qtl$id == "Chr09_11988331")
genotype_table_for_qtl = genotype_table_for_qtl[ c(-dup1[1],-dup2[1]) ,]

write.csv(genotype_table_for_qtl, file="genotype_table_for_qtl.csv",
          quote = F,
          row.names = F)

#dim()
chrpos= t( data.frame(  strsplit( genotype_table_for_qtl[,1],"_") ) )
chrpos = cbind(chrpos,genotype_table_for_qtl[,2])
rownames(chrpos) = 1:nrow(chrpos)

data =  data.frame( chrpos, genotype_table_for_qtl[,c(1,3)]  )
colnames(data) = c("Chromosome","Physical_position_Mb","Chrom","Marker_name","Genetic_position_cM")

data[,2] =as.numeric(data[,2])/1000000

data[,2]
save(data,file="data")


#install.packages("ggpubr")
library(ggpubr)
chr_size = read.table(file="Gmax_275_v2.0.fa.fai")


for(i in  1:20){
  data2 = data[ data[,1] == chr_list[i] , ]
  x = gghistogram(data2 , x="Physical_position_Mb",
                  title = paste(chr_list[i]), size=0.2,
                  binwidth = 1) 
  
  x = x + ggpubr::font("xy.text",size=8) 
  x = x + geom_vline( xintercept = chr_size[i,2]/1000000, color = "red",
                      linetype="dashed", size=0.2)
  message(paste0( chr_size[i,2]/1000000))
  
  x =  ggpubr::ggpar(x,font.x = c(8, "bold", "#000000"),
                     font.y = c(8, "bold", "#000000"), 
                     ylab = "Frequency",
                     xlim=c(0,60),ylim = c(0,25))
  assign(paste0("hi",i),x) 
}

gg= ggpubr::ggarrange(hi1,hi2,hi3,hi4,hi5,
                      hi6,hi7,hi8,hi9,hi10,
                      hi11,hi12,hi13,hi14,hi15,
                      hi16,hi17,hi18,hi19,hi20,
                      #labels = LETTERS,
                      ggtheme = theme,
                      ncol=4,nrow=5,
                      font.label = list(size = 16, color = "black"),
                      widths = 10, heights = 10,
                      align = "hv") 

ggpubr::ggexport(gg, filename ="bp_maker_plot_RILs.pdf",width=10,height=7)


for(i in  1:length(chr_names2)){
  data2 = data[ data[,3] == chr_names2[i] , ]
    #pp1 = ggpubr::ggscatter(data,"Physical map position", "Genetic map position")
  assign("x" , 
         ggpubr::ggscatter(data2, "Physical_position_Mb", "Genetic_position_cM",
                           title = paste(chr_names2[i]),color= "black" ,size=1)   )
  x = x + ggpubr::font("xy.text",size=9)
  assign(paste0("pp",i) , 
         ggpubr::ggpar(x,font.x = c(9, "bold", "#000000"),font.y = c(9, "bold", "#000000")))
  
}



gg = ggpubr::ggarrange(pp1, pp2, pp3, pp4, pp5 ,pp6,pp7,pp8,pp9,pp10,
                       pp11,pp12,pp13,pp14,pp15,pp16,pp17,pp18,pp19,pp20,
                       #labels = LETTERS,
                       ncol=4,nrow=5,
                       font.label = list(size = 16, color = "black"),
                       widths = 10, heights = 10,
                       align = "hv") 


x=10
ggpubr::ggexport(gg, filename ="bp_cm_plot_RILs.pdf",
                 width=10,height=10)



####
library("qtl")
library("LinkageMapView")


dat1 <- read.cross("csvsr", ".", 
                   "genotype_table_for_qtl.csv",
                   "pheno.csv")
plot.map(dat1)


