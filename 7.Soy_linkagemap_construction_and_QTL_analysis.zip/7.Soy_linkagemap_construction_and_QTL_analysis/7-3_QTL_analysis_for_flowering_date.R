

library("qtl")

dat1 <- read.cross("csvsr", ".", 
                          "genotype_table_for_qtl.csv",
                          "pheno_RILs.csv")

dat1

#########
testmapimp <- calc.genoprob(dat1, step=1) 

sum_dat1 = summary(dat1)
sum_dat1
write.csv(sum_dat1$n.mar,file="sum_dat1_nmar.csv")
genotype_table_for_qtl_2 = read.csv(file="genotype_table_for_qtl.csv")
markers_chr_gpos = paste0(genotype_table_for_qtl_2[,2],"_",genotype_table_for_qtl_2[,3])
length( unique(markers_chr_gpos) )


########
chrlist = c("01_1","02_1","03_1","04_1","05_1","06_1",
            "07_1","08_1","09_1","10_1","11_1","12_1",
            "13_1","14_1","15_1","16_1","17_1","18_1",
            "19_1","20_1")
res_df = data.frame(matrix(NA,nrow=length(chrlist),ncol=5))
res_df[,1] = chrlist
colnames(res_df)= c("Chromosome","Number of marker","Number of unique marker",
                    "Linkage map length","Average marker interval")

for(i in 1:length(chrlist)){
  linkagemap = dat1[["geno"]][[chrlist[i]]][["map"]]
  res_df[i,2] = length(linkagemap)
  res_df[i,3] = length(unique(linkagemap))
  res_df[i,4] = max(linkagemap)
  res_df[i,5] = max(linkagemap)/(length(unique(linkagemap))-1)
}

write.csv(res_df,file="linkagemap_summary.csv")






pdf(file=paste0("rf_image_RILs_not_imutated.pdf"))
plotRF(dat1)
dev.off()

png(file=paste0("Fig.2h_rf_image_RILs_not_imutated.png"), height=1000,width=1000)
plotRF(dat1)
dev.off()


##########QTL analysis
testmapimp <- calc.genoprob(dat1, step=1) 

for(i in 2:2){
  phenoname= colnames(testmapimp[["pheno"]])[i]
  phenoname
  
  
  #interval mapping (IM)
  out.simhk <- scanone(testmapimp, pheno.col=i, method="hk")
  
  operms <- scanone(testmapimp, n.perm=1000, method="hk",n.cluster=4,pheno.col = i)
  summary(out.simhk, perms=operms, alpha=0.05, pvalues=TRUE)
  summary(operms)
  
  write.csv( summary(out.simhk, perms=operms, alpha=0.05, pvalues=TRUE),
             file=paste0("sum_im_qtl_",i,"_",phenoname,".csv") )
  
  plot(out.simhk)
  summary(out.simhk)
  write.csv(out.simhk,file=paste0("out.simhk_",i,"_",phenoname,".csv"))
  
  #out.simhk[out.simhk$lod > summary(operms)[1] ,  ]
  #plot(out.simhk)
  
  pdf(file=paste0("sim",i,"_",phenoname,".pdf"),height=5,width=10)
  plot(out.simhk)
  abline(summary(operms)[1],0,col="red" )
  dev.off()
  
  #composite interval mapping(CIM)
  out.cimhk <- cim(testmapimp, n.marcovar=5, pheno.col=i, method="hk")
  operm <- cim(testmapimp,n.perm=1000,n.marcovar=5,pheno.col = i, method="hk")

  summary(operm)
  
  summary(out.cimhk, perms=operm, alpha=0.05, pvalues=TRUE)
  
  pdf(file=paste0("Fig.2g_cim",i,"_",phenoname,".pdf"),height=5,width=10)
  plot(out.cimhk)
  abline(summary(operm)[1],0,col="red" )
  dev.off()
  
  summary(out.cimhk)
  write.csv(out.cimhk,file=paste0("out.cimhk",i,"_",phenoname,".csv"))
  out.cimhk[out.cimhk$lod > summary(operm)[1] ,  ]
  write.csv( summary(out.cimhk, perms=operm, alpha=0.05, pvalues=TRUE),
             file=paste0("sum_cim_qtl",i,"_",phenoname,".csv" ))
  
  
  pdf(file=paste0("qtl_result_RILs_not_imputated",i,"_",phenoname,".pdf"))
  layout(matrix(1:1, ncol=1))
  plot(out.simhk, out.cimhk, col=c("blue", "red"),height=5,width=10)
  dev.off()
  
  res_operms= summary(operms)
  threshold_simhk = out.simhk[out.simhk[,3] > res_operms[1], ]
  threshold_simhk
  
  res_operm= summary(operm)
  threshold_cimhk = out.cimhk[out.cimhk[,3] > res_operm[1], ]
  threshold_cimhk
  
  write.csv(res_operm, file=paste0(phenoname,"_res_operm.csv"))
  write.csv(res_operms, file=paste0(phenoname,"_res_operms.csv"))
  write.csv(threshold_cimhk, file=paste0(phenoname,"threshold_cimhk_for_table.csv"))
  write.csv(threshold_simhk, file=paste0(phenoname,"threshold_simhk_for_table.csv"))
  save(res_operm,file=paste0("res_operm"))
  save(res_operms,file=paste0("res_operms"))
  save(threshold_cimhk,file=paste0("threshold_cimhk"))
  save(threshold_simhk,file=paste0("threshold_simhk"))
  
}


out.cimhk[out.cimhk$lod > summary(operm)[1] ,  ]

####E1####
#Chr06_21080395
chr06_marker= dat1[["geno"]][["06_1"]][["data"]]

chr06_marker[,colnames(chr06_marker) == "Chr06_21080395"]

data5= data.frame(chr06_marker[,colnames(chr06_marker) == "Chr06_21080395"],
                  dat1[["pheno"]][["Flowering.time..days..1999"]])

str(data5)
table(data5[,1])
data5[data5[,1] == 1, 1] = "A" 
data5[data5[,1] == 2, 1] = "H"
data5[data5[,1] == 3, 1] = "B"

library(multcomp)
library(ggpubr)

data5[,1] <-  factor( data5[,1], levels = c("A", "H", "B"))
colnames(data5) = c("Chr06_21080395","Flowering.time..days..1999")
gg5 = ggboxplot(data5,x = "Chr06_21080395", y="Flowering.time..days..1999",color= "Chr06_21080395",
                palette =c("#00AFBB", "#E7B800", "#FC4E07"),
                add = "jitter", shape ="Chr06_21080395" )
gg5


data5 = data5[data5$Chr06_21080395 != "H",]

res_data5<-aov(Flowering.time..days..1999~Chr06_21080395,d=data5)
summary(res_data5)
res2_data5<-glht(res_data5,linfct=mcp(Chr06_21080395="Tukey"))
summary(res2_data5)
cld(res2_data5)


####E2####
#Chr10_45131796
chr10_marker= dat1[["geno"]][["10_1"]][["data"]]

chr10_marker[,colnames(chr10_marker) == "Chr10_45131796"]

data4= data.frame(chr10_marker[,colnames(chr10_marker) == "Chr10_45131796"],
                  dat1[["pheno"]][["Flowering.time..days..1999"]])

str(data4)
table(data4[,1])
data4[data4[,1] == 1, 1] = "A" 
data4[data4[,1] == 2, 1] = "H"
data4[data4[,1] == 3, 1] = "B"

library(multcomp)
library(ggpubr)

data4[,1] <-  factor( data4[,1], levels = c("A", "H", "B"))
colnames(data4) = c("Chr10_45131796","Flowering.time..days..1999")
gg4 = ggboxplot(data4,
                x = "Chr10_45131796", 
                y="Flowering.time..days..1999",
                color= "Chr10_45131796",
                palette =c("#00AFBB", "#E7B800", "#FC4E07"),
                add = "jitter", 
                shape ="Chr10_45131796" )
gg4

data4 = data4[data4$Chr10_45131796 != "H",]

res_data4<-aov(Flowering.time..days..1999~Chr10_45131796,d=data4)
summary(res_data4)
res2_data4<-glht(res_data4,linfct=mcp(Chr10_45131796="Tukey"))
summary(res2_data4)
cld(res2_data4)

#library(cowplot)
ggar = ggpubr::ggarrange(gg5,gg4,ncol = 2,nrow = 1, align = "hv") 
ggpubr::ggexport(ggar, filename ="RILs_gene_effect_qtls_.pdf",width=10,height=5)


######geneticmap_phisicalmap_plot#########

library(ggpubr)

out.cimhk[out.cimhk$lod > summary(operm)[1] ,  ]

####Chr06_21080284####
df = out.cimhk
data = data.frame(df[df$chr == "06_1",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "Chr06", 5] = NA
write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)
gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
start = 140
end   = 160

QTL_chr06_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
  geom_line() +
  ggtitle("QTL chr06")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_chr06_genetic = QTL_chr06_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                                    color = 1, linetype="solid", linewidth=0.5)+ 
  scale_x_continuous(breaks=seq(start,end,by=1), limits=c(start,end))

#guides(colour=FALSE)

QTL_chr06_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)
phy_range= range(na.omit(  data[data$cM >start & data$cM < end,  6] )  )

QTL_chr06_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(floor(phy_range[1]),ceiling(phy_range[2]),by=1), limits=c(floor(phy_range[1]),ceiling(phy_range[2]) ))


QTL_chr06_physical = QTL_chr06_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),
                                                      color = 1, linetype="solid", size=0.5)

genes_name_06= c("E1")
genes_pos_06= c(20207077)

for(k in 1:length(genes_name_06)){
  QTL_chr06_physical = QTL_chr06_physical + geom_vline(  xintercept = genes_pos_06[k]/(10^6) ,　　
                                                         linetype="solid",
                                                         color = "#FF0000", 
                                                         size=0.5)
}
QTL_chr06_physical

(gg = ggpubr::ggarrange(QTL_chr06_genetic,QTL_chr06_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_chr06_genetic_physicalmap.pdf",width=8,height=4)




####Chr10_45131796####
df = out.cimhk
data = data.frame(df[df$chr == "10_1",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "Chr10", 5] = NA
write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)
gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
start = 160
end   = 180

QTL_chr10_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
  geom_line() +
  ggtitle("QTL chr10")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_chr10_genetic = QTL_chr10_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                                    color = 1, linetype="solid", linewidth=0.5)+ 
  scale_x_continuous(breaks=seq(start,end,by=1), limits=c(start,end))

#guides(colour=FALSE)

QTL_chr10_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)
phy_range= range(na.omit(  data[data$cM >start & data$cM < end,  6] )  )

QTL_chr10_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(floor(phy_range[1]),ceiling(phy_range[2]),by=0.2), limits=c(floor(phy_range[1]),ceiling(phy_range[2]) ))


QTL_chr10_physical = QTL_chr10_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),
                                                      color = 1, linetype="solid", size=0.5)

genes_name_10= c("E2")
genes_pos_10= c(45294735)

for(k in 1:length(genes_name_06)){
  QTL_chr10_physical = QTL_chr10_physical + geom_vline(  xintercept = genes_pos_10[k]/(10^6) ,　　
                                                         linetype="solid",
                                                         color = "#FF0000", 
                                                         size=0.5)
}
QTL_chr10_physical

(gg = ggpubr::ggarrange(QTL_chr10_genetic,QTL_chr10_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_chr10_genetic_physicalmap.pdf",width=8,height=4)




########Histgram of RILs#####
Misuzudaizu = 58
MOSHIDEU_GONG503  = 44
RILs_pheno = na.omit(dat1[["pheno"]][["Flowering.time..days..1999"]])

pa_pheno = data.frame(c("Misuzudaizu","MOSHIDEU_GONG503"),c(Misuzudaizu, MOSHIDEU_GONG503))

range(RILs_pheno)
library(ggpubr)

###
data = pa_pheno
phe1 = ggpubr::gghistogram(data, 
                           x = "Flowering.time..days..1999",
                           add = "mean", 
                           #rug = TRUE,
                           color = "Line", 
                           fill = "Line",
                           palette =  c("#ff00ff", "#0000ff"),
                           binwidth = 1
)
phe1 = phe1 + ggpubr::font("xy.text",size=10) 
#phe1 = phe1 + geom_vline( xintercept = chr_size[i,2]/1000000, 
#                          color = "red", linetype="dashed", size=0.2)
phe1 =  ggpubr::ggpar(phe1,font.x = c(10, "bold", "#000000"),
                      font.y = c(10, "bold", "#000000"), 
                      ylab = "Frequency",
                      xlim=c(range(RILs_pheno)[1]-1,range(RILs_pheno)[2]+1),ylim = c(0,15), 
                      width = 10,height=2
) + theme(legend.position = "none")




RColorBrewer::display.brewer.all()


data = data.frame( c( rep("RILs",length(RILs_pheno)) ) ,RILs_pheno)
colnames(data) = c("RILs","Flowering.time..days..1999")
phe2 = gghistogram(data , x="Flowering.time..days..1999",
                   #title = paste("Flowering.time..days..1999"),
                   ylab = "Frequency",
                   xlab = "Flowering.time..days..1999",
                   #size=0.2,
                   binwidth = 1,
                   palette =  c("#edae00") ,
                   color =  "RILs", 
                   fill = "RILs"  ) 
phe2 = phe2 + ggpubr::font("xy.text",size=10) 
phe2 = phe2 + geom_vline( xintercept =  mean(Misuzudaizu),
                          color = "#ff00ff", linetype="dashed", size=0.5)
phe2 = phe2 + geom_vline( xintercept =  mean(MOSHIDEU_GONG503),
                          color = "#0000ff", linetype="dashed", size=0.5)
phe2 =  ggpubr::ggpar(phe2,
                      font.x = c(10, "bold", "#000000"),
                      font.y = c(10, "bold", "#000000"), 
                      ylab = "Frequency",
                      xlab = "Flowering.time..days..1999",
                      xlim=c(range(RILs_pheno)[1]-1,range(RILs_pheno)[2]+1), lim = c(0,25)
)　+ theme(legend.position = "none")

phe2 + theme(legend.position="top")
phe2 + theme(legend.position = "none")
phe2


##
d1 = data.frame( c( rep("RILs",length(RILs_pheno)) ) ,RILs_pheno, stringsAsFactors = F)
d2 =  pa_pheno
colnames(d1) = c("Line","Flowering.time..days..1999")
colnames(d2) = c("Line","Flowering.time..days..1999")
data = rbind(d1,d2)

p_for_label = ggpubr::gghistogram(data, 
                                  x = "Flowering.time..days..1999",
                                  #add = "mean", 
                                  #rug = TRUE,
                                  color = "Line", 
                                  fill = "Line",
                                  palette =  c( "#ff00ff", "#0000ff","#edae00"),
                                  binwidth = 1)
library("lemon")
p_legend <- lemon::g_legend(p_for_label)
grid::grid.newpage()
grid::grid.draw(p_legend)
(gg = ggpubr::ggarrange(p_legend,phe2,ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="pheno_plot_RILs.pdf",width=4,height=5)

summary(dat1)





