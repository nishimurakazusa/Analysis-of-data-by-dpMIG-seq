
SEQLIBS=c("Bof5_01","Bof5_02","Bof5_03","Bof5_04",
          "bbf5_01","bbf5_02","bbf5_03","bbf5_04",
          "bbf5_05","bbf5_06","bbf5_07","bbf5_08",
          "ctf5_01","ctf5_02","ctf5_03","ctf5_04",
          "dkf5_01","dkf5_02","dkf5_03","dkf5_04",
          "osf1_01","osf1_02","osf1_03","osf1_04",
          "osf1_05","osf1_06","osf1_07","osf1_08",
          "osf2_01","osf2_02","osf2_03","osf2_04",
          "osf2_05","osf2_06","osf2_07","osf2_08",
          "osf3_01","osf3_02","osf3_03","osf3_04",
          "osf3_05","osf3_06","osf3_07","osf3_08",
          "osf4_01","osf4_02","osf4_03","osf4_04",
          "osf4_05","osf4_06","osf4_07","osf4_08",
          "osf5_01","osf5_02","osf5_03","osf5_04",
          "osf5_05","osf5_06","osf5_07","osf5_08",
          "slf1_01","slf1_02","slf1_03","slf1_04",
          "slf1_05","slf1_06","slf1_07","slf1_08",
          "slf2_01","slf2_02","slf2_03","slf2_04",
          "slf2_05","slf2_06","slf2_07","slf2_08",
          "slf3_01","slf3_02","slf3_03","slf3_04",
          "slf3_05","slf3_06","slf3_07","slf3_08",
          "slf4_01","slf4_02","slf4_03","slf4_04",
          "slf4_05","slf4_06","slf4_07","slf4_08",
          "slf5_01","slf5_02","slf5_03","slf5_04",
          "slf5_05","slf5_06","slf5_07","slf5_08",
          "rhf5_01","rhf5_02","rhf5_03","rhf5_04" )


res_rate = data.frame(matrix(NA,ncol = 2 ,nrow = length(SEQLIBS) ))
colnames(res_rate) = c("fastq_name","mapping_rate")


for( i in 1:length(SEQLIBS)){
  
  read_count = read.table(file=paste0("mapping_rate/",SEQLIBS[i],"_read-count"))
  unmap_read = read.table(file=paste0("mapping_rate/",SEQLIBS[i],"_unmap-read"))
  
  rate = ((read_count/4*2)- unmap_read )/(read_count/4*2)
   message(paste0(rate))
  res_rate[i,] = c(SEQLIBS[i],rate)
  
  
}



res_rate2 = data.frame( res_rate, t(data.frame( str_split(res_rate$fastq_name,"_")) ) )

res_rate2




res_rate2$SP  = substr(res_rate2[,3], 1,2 )
res_rate2$LIB = substr(res_rate2[,3], 4,5 )


data = res_rate2[,c(2,4,5,6,3)]


library(ggpubr)
colnames(data) = c("Mappong_rate","Line","Species","Library","Library_name")
write.csv(data, file="mappimg_rate.csv")

SP = c("os","sl")
j=1

for(j in 1:2){
  data2 = data[data$Species == SP[j],]
  gg = ggboxplot(data2,x = "Library",
                 y="Mappong_rate",
                 color = "Library",
                 add= "jitter") +
    scale_y_continuous(limits =c(0,1), breaks=seq(0,1,by=0.2))
  gg
  ggsave(gg,file=paste0(SP[j],"_mapping_rate.pdf"),height=3,width=5 )
}


data2 = data[data$Species != SP[1] & data$Species != SP[2],]
gg = ggboxplot(data2,x = "Library_name",
               y="Mappong_rate",
               color = "Library_name",
               add= "jitter") +
  scale_y_continuous(limits =c(0,1), breaks=seq(0,1,by=0.2))
gg
ggsave(gg,file=paste0("mapping_rate_Bo_bb_ct_dk_rh.pdf"),height=3,width=5 )





