
#require(pcaMethods)
#require(rrBLUP)
#require(qqman)
#require(glmnet)
require(vcfR)
require(ggpubr)
require(ggrepel)

#filtering by depth
#set parameter
#b =10
FilterbyDP = function(b){
  
  filter_dp_progeny = b
  
  dp_pro = dp
  colnames(dp_pro)
  
  gt.score_pro = gt.score
  
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  
  gt.score_filtered = gt.score_pro
  
  all_data = data.frame(chrom,pos,gt.score_filtered)
  
  str(all_data)
  
  return(all_data)
}


SP = c("osf","slf")
hetero= c(0,1)

methods = c(1,2,3,4,5)
#i=1
#j=1
#dp_limit = 10

dir.create("snp_for_mega_fasta")
dir.create("PCA")


res_df = data.frame(matrix(NA, nrow = 5, ncol = 2))
j=4
j=1
i=1


library(stringr)

data_stat =  read.table(file=paste0("stat.tsv" ),header=T)
data_stat[,5] = as.numeric(str_replace_all(data_stat[,5],pattern = ",", replacement = "" ))
data_stat$Gb = data_stat[,5]/(10^9)
data_stat$Gb
data_stat$Coefficient_for_correction = (0.3/data_stat$Gb)



#########Oryza sativa L.##########
for(j in 1){

  #i=1
  
  for(i in 1:length(methods) ){
    #assign( paste0( "_vcf_",N_pos[i],"_",SP[j]), 
    #      read.vcfR(paste0( "vcf/",N_pos[i],SP[j],".samtools.vcf" )) )
    
    assign( "vcf", 
            read.vcfR(paste0("filtered_",SP[j],methods[i],"_samtools.recode.vcf" )) )
    
    # extract genotype data from vcf
    gt = extract.gt(vcf)
    #gt[1:10,]
    #dim(gt)
    dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
    
    #k=1
    #rawdata/Bof5_01_1.fastq.gz
    
    for(k in 1:8){ 
      dp[,k] = dp[,k]*data_stat[ data_stat$file == paste0("rawdata/",SP[j],i,"_0",k,"_1.fastq.gz"),
                                 "Coefficient_for_correction"]
    
    }
    
    # get marker information (chromosone numbers and positions)
    chrom <- getCHROM(vcf)
    pos <- getPOS(vcf)
    
    # create a matrix of gt scores
    gt.score <- matrix(NA, nrow(gt), ncol(gt))
    gt.score[gt == "0/0"] <- -1
    gt.score[gt == "1/1"] <- 1
    gt.score[gt == "0|0"] <- -1
    gt.score[gt == "1|1"] <- 1

    if(hetero[j] == 1){
    gt.score[gt == "0/1"] <- 0
    gt.score[gt == "0|1"] <- 0
    }
    
    
    #gt.score[1:10,]
    #dim(gt.score)
    #str(gt.score)
    
    # name the rows and columns of matrix
    rownames(gt.score) <- rownames(gt)
    colnames(gt.score) <- colnames(gt)
    #gt.score[1:10, 1]
  
    ###filtering by coverage depth
    dp_limit = 10
    all_data = FilterbyDP(dp_limit)
    #all_data[1:10,]
    #dim(all_data)
    
    #extracted hoge% typing loci
    df = data.frame(all_data,stringsAsFactors = F)
  
    data_count= function(x){
        return( sum( !is.na(x) ) )
    }
      
    row_with_no_missing = apply(df[,3:10],1,data_count) == 8
    
    df2  = df[row_with_no_missing,]
    df3  = df2[apply(df2[,3:10],1,var) != 0,]
    
    res_df[i,1] = nrow(df3)
    assign( paste0( SP[j],methods[i],"_chr_pos") ,  paste0(df3[,1],"_",df3[,2] ) ) 
    write.csv(df3, file= paste0( SP[j],methods[i],".csv"))
    
    pca = prcomp(t(df3[,3:10]),scale=T)
    pca_res = data.frame(pca$x[,1:2])
    pca_res$Line = c("WRC13","WRC23","WRC41","WRC42",
                     "WRC44","WRC55","WRC59","WRC63")
    
    
    gg = ggscatter(data=pca_res ,x="PC1",y = "PC2",col = "Line")+
      geom_text_repel(aes(x = PC1, y = PC2, label = Line, col=Line), 
                      family = "serif", size = 4)+ theme(legend.position = "none")

    
    gg
    ggsave(file=paste0("PCA/",SP[j],methods[i],"_pca.pdf"),
           height = 3, width =3)
    
    
    #################fasta for NJ tree
    chrom <- getCHROM(vcf)
    pos <- getPOS(vcf)
    ref = getREF(vcf)
    alt = getALT(vcf)
    ref_alt_df = data.frame(ref,alt)
    ref_alt_df2 = ref_alt_df[row_with_no_missing,]
    ref_alt_df3 = ref_alt_df2[apply(df2[,3:10],1,var) != 0,]
    
    f1 =      (ref_alt_df3[,1] == "A" | 
               ref_alt_df3[,1] == "T" |
               ref_alt_df3[,1] == "G" |
               ref_alt_df3[,1] == "C") &
              (ref_alt_df3[,2] == "A" | 
               ref_alt_df3[,2] == "T" |
               ref_alt_df3[,2] == "G" |
               ref_alt_df3[,2] == "C") 

    #nchar(ref_alt_df2$ref)
    
    ref_alt_df4 = ref_alt_df3[f1,]
    df4 = df3[f1,3:ncol(df3)]
    
    dim(df4)
    dim(ref_alt_df4)
    
    df4[,1:8]
    
    gt.cha <- matrix(NA, nrow(df4), ncol(df4))
    #######
    for(l in 1:nrow(df4)){
      gt.cha[ l,df4[l,] == -1  ] =  paste0(ref_alt_df4[l,1],ref_alt_df4[l,1])
      gt.cha[ l,df4[l,] ==  0  ] =  paste0(ref_alt_df4[l,1],ref_alt_df4[l,2])
      gt.cha[ l,df4[l,] ==  1  ] =  paste0(ref_alt_df4[l,2],ref_alt_df4[l,2])
    }
    gt.cha[1:10,1:8]
    
    # name the rows and columns of matrix
    
    rownames(gt.cha) <- rownames(df4)
    colnames(gt.cha) <- colnames(df4)
    
    gt.cha[1:10,1:8]
    
    #write.csv(gt.cha,file="snp_for_mega.csv")
    #df5 =  read.csv(file = "snp_for_mega.csv",row.names = 1,stringsAsFactors = F, header=T)
    df5 = gt.cha
    str(df5)
    #df5[df5 == TRUE] = "T"
    
    k=1
    cat(">",colnames(df5)[k] ,"\n" ,file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"), sep="", append = F)
    cat(df5[,k],"\n", file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"), sep="", append = T, collapse = "")
    
    for( k in 2:ncol(df5)){
      message(paste0(i,"回目の処理を事項"))
      cat(">",colnames(df5)[k] ,"\n" ,file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"),sep="",append = T)
      cat(df5[,k],"\n","\n" ,file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"),sep="", append = T)
    }
    
  }#Methods
  
}#Species



  

library(VennDiagram)
data <- list(osf1_chr_pos, osf2_chr_pos, osf3_chr_pos, osf4_chr_pos,osf5_chr_pos)
venn.diagram(data, filename="os_venn.png", imagetype="png",
             category.names = c("osf1","osf2","osf3","osf4","osf5"), 
             fill=c(1,2,3,4,5))

#data[[j]]
res_common = data.frame(matrix(NA,5,5))

for(n in 1:5){
 for(m in n:5){
  res_common[n,m]= length( intersect(data[[n]],data[[m]]) )/length(unique(c(data[[n]],data[[m]]))) 
}
}

write.csv(res_common,file=paste0(SP[j],"_common_df.csv"))
res_df[,2] = paste0(SP[j],methods)
write.csv(res_df,file=paste0(SP[j],"_res_df.csv"))

library(ggpubr)
colnames(res_df) = c("Number of polymorphisms","Methods")
gg = ggbarplot(res_df,x = "Methods",
               y="Number of polymorphisms",
               color = "Methods",
               fill  = "Methods")
gg
ggsave(gg,file=paste0(SP[j],"_n_of_snp.pdf"),height=3,width=5 )


#########Solanum lycopersicum L.##########

for(j in 2){
  
  #i=1
  
  for(i in 1:length(methods) ){
    #assign( paste0( "_vcf_",N_pos[i],"_",SP[j]), 
    #      read.vcfR(paste0( "vcf/",N_pos[i],SP[j],".samtools.vcf" )) )
    
    assign( "vcf", 
            read.vcfR(paste0("filtered_",SP[j],methods[i],"_samtools.recode.vcf" )) )
    
    # extract genotype data from vcf
    gt = extract.gt(vcf)
    #gt[1:10,]
    #dim(gt)
    dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
    
    #k=1
    #rawdata/Bof5_01_1.fastq.gz
    
    for(k in 1:8){ 
      dp[,k] = dp[,k]*data_stat[ data_stat$file == paste0("rawdata/",SP[j],i,"_0",k,"_1.fastq.gz"),
                                 "Coefficient_for_correction"]
      
    }
    
    # get marker information (chromosone numbers and positions)
    chrom <- getCHROM(vcf)
    pos <- getPOS(vcf)
    
    # create a matrix of gt scores
    gt.score <- matrix(NA, nrow(gt), ncol(gt))
    gt.score[gt == "0/0"] <- -1
    gt.score[gt == "1/1"] <- 1
    gt.score[gt == "0|0"] <- -1
    gt.score[gt == "1|1"] <- 1
    
    if(hetero[j] == 1){
      gt.score[gt == "0/1"] <- 0
      gt.score[gt == "0|1"] <- 0
    }
    
    
    #gt.score[1:10,]
    #dim(gt.score)
    #str(gt.score)
    
    # name the rows and columns of matrix
    rownames(gt.score) <- rownames(gt)
    colnames(gt.score) <- colnames(gt)
    #gt.score[1:10, 1]
    
    ###filtering by coverage depth
    dp_limit = 10
    all_data = FilterbyDP(dp_limit)
    #all_data[1:10,]
    #dim(all_data)
    
    #extracted hoge% typing loci
    df = data.frame(all_data,stringsAsFactors = F)
    
    data_count= function(x){
      return( sum( !is.na(x) ) )
    }
    
    row_with_no_missing = apply(df[,3:10],1,data_count) == 8
    
    df2  = df[row_with_no_missing,]
    df3  = df2[apply(df2[,3:10],1,var) != 0,]
    
    res_df[i,1] = nrow(df3)
    assign( paste0( SP[j],methods[i],"_chr_pos") ,  paste0(df3[,1],"_",df3[,2] ) ) 
    write.csv(df3, file= paste0( SP[j],methods[i],".csv"))
    
    
    
    #####PCA_analysis
    pca = prcomp(t(df3[,3:10]),scale=T)
    pca_res = data.frame(pca$x[,1:2])
    pca_res$Line = c("SL1","SL2","SL3","SL4",
                     "SL5","SL6","SL7","SL8")
    
    
    gg = ggscatter(data=pca_res ,x="PC1",y = "PC2",col = "Line")#+
    #  geom_text_repel(aes(x = PC1, y = PC2, label = Line, col=Line), 
    #                  family = "serif", size = 4)#+ theme(legend.position = "none")
    
    
    gg
    ggsave(file=paste0("PCA/",SP[j],methods[i],"_pca.pdf"),
           height = 4.7, width =4)
    
    
    #################fasta for NJ tree
    chrom <- getCHROM(vcf)
    pos <- getPOS(vcf)
    ref = getREF(vcf)
    alt = getALT(vcf)
    ref_alt_df = data.frame(ref,alt)
    ref_alt_df2 = ref_alt_df[row_with_no_missing,]
    ref_alt_df3 = ref_alt_df2[apply(df2[,3:10],1,var) != 0,]
    
    f1 =      (ref_alt_df3[,1] == "A" | 
                 ref_alt_df3[,1] == "T" |
                 ref_alt_df3[,1] == "G" |
                 ref_alt_df3[,1] == "C") &
      (ref_alt_df3[,2] == "A" | 
         ref_alt_df3[,2] == "T" |
         ref_alt_df3[,2] == "G" |
         ref_alt_df3[,2] == "C") 
    
    #nchar(ref_alt_df2$ref)
    
    ref_alt_df4 = ref_alt_df3[f1,]
    df4 = df3[f1,3:ncol(df3)]
    
    dim(df4)
    dim(ref_alt_df4)
    
    df4[,1:8]
    
    gt.cha <- matrix(NA, nrow(df4), ncol(df4))
    #######
    for(l in 1:nrow(df4)){
      gt.cha[ l,df4[l,] == -1  ] =  paste0(ref_alt_df4[l,1],ref_alt_df4[l,1])
      gt.cha[ l,df4[l,] ==  0  ] =  paste0(ref_alt_df4[l,1],ref_alt_df4[l,2])
      gt.cha[ l,df4[l,] ==  1  ] =  paste0(ref_alt_df4[l,2],ref_alt_df4[l,2])
    }
    gt.cha[1:10,1:8]
    
    # name the rows and columns of matrix
    
    rownames(gt.cha) <- rownames(df4)
    colnames(gt.cha) <- colnames(df4)
    
    gt.cha[1:10,1:8]
    
    #write.csv(gt.cha,file="snp_for_mega.csv")
    #df5 =  read.csv(file = "snp_for_mega.csv",row.names = 1,stringsAsFactors = F, header=T)
    df5 = gt.cha
    str(df5)
    #df5[df5 == TRUE] = "T"
    
    k=1
    cat(">",colnames(df5)[k] ,"\n" ,file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"), sep="", append = F)
    cat(df5[,k],"\n", file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"), sep="", append = T, collapse = "")
    
    for( k in 2:ncol(df5)){
      message(paste0(i,"回目の処理を事項"))
      cat(">",colnames(df5)[k] ,"\n" ,file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"),sep="",append = T)
      cat(df5[,k],"\n","\n" ,file=paste0("snp_for_mega_fasta/",SP[j],methods[i],".fasta"),sep="", append = T)
    }
    
  }#Methods
  
}#Species





library(VennDiagram)
data <- list(slf1_chr_pos, slf2_chr_pos, slf3_chr_pos, slf4_chr_pos,slf5_chr_pos)
venn.diagram(data, filename="sl_venn.png", imagetype="png",
             category.names = c("slf1","slf2","slf3","slf4","slf5"), 
             fill=c(1,2,3,4,5))

#data[[j]]
res_common = data.frame(matrix(NA,5,5))

for(n in 1:5){
  for(m in n:5){
    res_common[n,m] = length( intersect(data[[n]],data[[m]]) )/length(unique(c(data[[n]],data[[m]]))) 
  }
}

write.csv(res_common,file=paste0(SP[j],"_common_df.csv"))
res_df[,2] = paste0(SP[j],methods)
write.csv(res_df,file=paste0(SP[j],"_res_df.csv"))

library(ggpubr)
colnames(res_df) = c("Number of polymorphisms","Methods")
gg = ggbarplot(res_df,x = "Methods",
               y="Number of polymorphisms",
               color = "Methods",
               fill  = "Methods")
gg
ggsave(gg,file=paste0(SP[j],"_n_of_snp.pdf"),height=3,width=5 )


