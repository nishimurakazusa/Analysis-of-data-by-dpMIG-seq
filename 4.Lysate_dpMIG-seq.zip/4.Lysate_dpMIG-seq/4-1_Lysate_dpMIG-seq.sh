#Making directories
mkdir sam
mkdir bam
mkdir vcf
mkdir fastq
mkdir reports_trim

seqkit stat rawdata/*fastq.gz > stat.tsv

SEQLIBS=(Bof5_01 Bof5_02 Bof5_03 Bof5_04 \
bbf5_01 bbf5_02 bbf5_03 bbf5_04 bbf5_05 bbf5_06 bbf5_07 bbf5_08 \
ctf5_01 ctf5_02 ctf5_03 ctf5_04 dkf5_01 dkf5_02 dkf5_03 dkf5_04 \
osf1_01 osf1_02 osf1_03 osf1_04 osf1_05 osf1_06 osf1_07 osf1_08 \
osf2_01 osf2_02 osf2_03 osf2_04 osf2_05 osf2_06 osf2_07 osf2_08 \
osf3_01 osf3_02 osf3_03 osf3_04 osf3_05 osf3_06 osf3_07 osf3_08 \
osf4_01 osf4_02 osf4_03 osf4_04 osf4_05 osf4_06 osf4_07 osf4_08 \
osf5_01 osf5_02 osf5_03 osf5_04 osf5_05 osf5_06 osf5_07 osf5_08 \
slf1_01 slf1_02 slf1_03 slf1_04 slf1_05 slf1_06 slf1_07 slf1_08 \
slf2_01 slf2_02 slf2_03 slf2_04 slf2_05 slf2_06 slf2_07 slf2_08 \
slf3_01 slf3_02 slf3_03 slf3_04 slf3_05 slf3_06 slf3_07 slf3_08 \
slf4_01 slf4_02 slf4_03 slf4_04 slf4_05 slf4_06 slf4_07 slf4_08 \
slf5_01 slf5_02 slf5_03 slf5_04 slf5_05 slf5_06 slf5_07 slf5_08 \
rhf5_01 rhf5_02 rhf5_03 rhf5_04)

##Trimming with trimmomatic
for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/${seqlib}_1.fastq.gz rawdata/${seqlib}_2.fastq.gz \
fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_unpaired_output_1.fq \
fastq/${seqlib}_paired_output_2.fq fastq/${seqlib}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
done

for seqlib in ${SEQLIBS[@]}; do
fastqc --nogroup -o ./reports_trim fastq/${seqlib}_paired_output_1.fq
fastqc --nogroup -o ./reports_trim fastq/${seqlib}_paired_output_2.fq
done
cd reports_trim
multiqc .
cd ../

#######Rice
thread=20
REF=../ref/rice/IRGSP-1.0_genome.fasta
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF

SEQLIBS=(osf1_01 osf1_02 osf1_03 osf1_04 osf1_05 osf1_06 osf1_07 osf1_08 \
osf2_01 osf2_02 osf2_03 osf2_04 osf2_05 osf2_06 osf2_07 osf2_08 \
osf3_01 osf3_02 osf3_03 osf3_04 osf3_05 osf3_06 osf3_07 osf3_08 \
osf4_01 osf4_02 osf4_03 osf4_04 osf4_05 osf4_06 osf4_07 osf4_08 \
osf5_01 osf5_02 osf5_03 osf5_04 osf5_05 osf5_06 osf5_07 osf5_08)

##Mapping using BWA
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(1 2 3 4 5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/osf${numlib}*.sorted.bam \
 | bcftools call -c -v -o osf${numlib}_samtools.vcf
done

for numlib in ${NUMLIBS[@]}; do
vcftools --vcf osf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_osf${numlib}_samtools
done

#######Tomato
SEQLIBS=(slf1_01 slf1_02 slf1_03 slf1_04 slf1_05 slf1_06 slf1_07 slf1_08 \
slf2_01 slf2_02 slf2_03 slf2_04 slf2_05 slf2_06 slf2_07 slf2_08 \
slf3_01 slf3_02 slf3_03 slf3_04 slf3_05 slf3_06 slf3_07 slf3_08 \
slf4_01 slf4_02 slf4_03 slf4_04 slf4_05 slf4_06 slf4_07 slf4_08 \
slf5_01 slf5_02 slf5_03 slf5_04 slf5_05 slf5_06 slf5_07 slf5_08)

thread=20
REF=../ref/tomato/tomato_ref.fasta
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF

##Mapping using BWA
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(1 2 3 4 5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/slf${numlib}*.sorted.bam \
 | bcftools call -c -v -o slf${numlib}_samtools.vcf
done

for numlib in ${NUMLIBS[@]}; do
vcftools --vcf slf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_slf${numlib}_samtools
done






#######Citrus
SEQLIBS=(ctf5_01 ctf5_02 ctf5_03 ctf5_04)
thread=20
REF=../ref/citrus/HWB.chromosome.fa
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF

##Mapping using BWA
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/ctf${numlib}*.sorted.bam \
 | bcftools call -c -v -o ctf${numlib}_samtools.vcf
vcftools --vcf ctf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_ctf${numlib}_samtools
done


#######Cabbage
SEQLIBS=(bof5_01 bof5_02 bof5_03 bof5_04)
thread=20
REF=../ref/cabbage/GCF_000695525.1_BOL_genomic.fna
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF
##Mapping using bwa
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/Bof${numlib}*.sorted.bam \
 | bcftools call -c -v -o bof${numlib}_samtools.vcf
vcftools --vcf bof${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_bof${numlib}_samtools
done


#Persimmon
SEQLIBS=(dkf5_01 dkf5_02 dkf5_03 dkf5_04)
thread=20
REF=../ref/persimmon/DLO_r1.1.fasta
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF
##Mapping using bwa
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/dkf${numlib}*.sorted.bam \
 | bcftools call -c -v -o dkf${numlib}_samtools.vcf
vcftools --vcf dkf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_dkf${numlib}_samtools
done


###Pyrus
SEQLIBS=(ppf5_01 ppf5_02 ppf5_03 ppf5_04)
thread=20
REF=../ref/pyrus/PPY_r1.0.pmol.fasta
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF
##Mapping using bwa
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/ppf${numlib}*.sorted.bam \
 | bcftools call -c -v -o ppf${numlib}_samtools.vcf
vcftools --vcf ppf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_ppf${numlib}_samtools
done


#####Rose
SEQLIBS=(rhf5_01 rhf5_02 rhf5_03 rhf5_04)
thread=20
REF=../ref/rose/GCA_002994745.2_RchiOBHm-V2_genomic.fna
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF
##Mapping using bwa
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/rhf${numlib}*.sorted.bam \
 | bcftools call -c -v -o rhf${numlib}_samtools.vcf
vcftools --vcf rhf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_rhf${numlib}_samtools
done


#####Blueberry
SEQLIBS=(bbf5_01 bbf5_02 bbf5_03 bbf5_04 bbf5_05 bbf5_06 bbf5_07 bbf5_08)
thread=20
REF=../ref/blueberry/V_corymbosum_genome_Draper_v1.hap1.fasta
samtools faidx $REF
gatk CreateSequenceDictionary -R $REF
bwa index -p $REF $REF
##Mapping using bwa
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

NUMLIBS=(5)
for numlib in ${NUMLIBS[@]}; do
samtools mpileup -uf $REF -d 0 -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/bbf${numlib}*.sorted.bam \
 | bcftools call -c -v -o bbf${numlib}_samtools.vcf
vcftools --vcf bbf${numlib}_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_bbf${numlib}_samtools
done

####Mapping rate

mkdir mapping_rate
SEQLIBS=(Bof5_01 Bof5_02 Bof5_03 Bof5_04 \
bbf5_01 bbf5_02 bbf5_03 bbf5_04 bbf5_05 bbf5_06 bbf5_07 bbf5_08 \
ctf5_01 ctf5_02 ctf5_03 ctf5_04 dkf5_01 dkf5_02 dkf5_03 dkf5_04 \
osf1_01 osf1_02 osf1_03 osf1_04 osf1_05 osf1_06 osf1_07 osf1_08 \
osf2_01 osf2_02 osf2_03 osf2_04 osf2_05 osf2_06 osf2_07 osf2_08 \
osf3_01 osf3_02 osf3_03 osf3_04 osf3_05 osf3_06 osf3_07 osf3_08 \
osf4_01 osf4_02 osf4_03 osf4_04 osf4_05 osf4_06 osf4_07 osf4_08 \
osf5_01 osf5_02 osf5_03 osf5_04 osf5_05 osf5_06 osf5_07 osf5_08 \
slf1_01 slf1_02 slf1_03 slf1_04 slf1_05 slf1_06 slf1_07 slf1_08 \
slf2_01 slf2_02 slf2_03 slf2_04 slf2_05 slf2_06 slf2_07 slf2_08 \
slf3_01 slf3_02 slf3_03 slf3_04 slf3_05 slf3_06 slf3_07 slf3_08 \
slf4_01 slf4_02 slf4_03 slf4_04 slf4_05 slf4_06 slf4_07 slf4_08 \
slf5_01 slf5_02 slf5_03 slf5_04 slf5_05 slf5_06 slf5_07 slf5_08 \
ppf5_01 ppf5_02 ppf5_03 ppf5_04 rhf5_01 rhf5_02 rhf5_03 rhf5_04 )

for seqlib in ${SEQLIBS[@]}; do
cat fastq/${seqlib}_paired_output_1.fq | wc -l > mapping_rate/${seqlib}_read-count
samtools view -f 4 bam/${seqlib}.sorted.bam | wc -l > mapping_rate/${seqlib}_unmap-read
done
