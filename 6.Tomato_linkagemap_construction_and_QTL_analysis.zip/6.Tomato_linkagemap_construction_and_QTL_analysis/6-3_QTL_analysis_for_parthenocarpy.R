

library("qtl")

dat1 <- read.cross("csvsr", ".", 
                   "genotype_table_for_qtl.csv",
                   "pheno_for_qtl.csv")
plot.map(dat1)

######

#plot(dat1)
sum_dat1 = summary(dat1)
write.csv(sum_dat1$n.mar,file="sum_dat1_nmar.csv")
genotype_table_for_qtl_2 = read.csv(file="genotype_table_for_qtl.csv")
markers_chr_gpos = paste0(genotype_table_for_qtl_2[,2],"_",genotype_table_for_qtl_2[,3])
length( unique(markers_chr_gpos) )



########
chrlist = c("01_1","02_1","03_1","04_1","05_1","06_1",
            "07_1","08_1","09_1","10_1","11_1","12_1")
res_df = data.frame(matrix(NA,nrow=length(chrlist),ncol=5))
res_df[,1] = chrlist
colnames(res_df)= c("Chromosome","Number of marker","Number of unique marker",
                    "Linkage map length","Average marker interval")

for(i in 1:length(chrlist)){
  linkagemap = dat1[["geno"]][[chrlist[i]]][["map"]]
  res_df[i,2] = length(linkagemap)
  res_df[i,3] = length(unique(linkagemap))
  res_df[i,4] = max(linkagemap)
  res_df[i,5] = max(linkagemap)/(length(unique(linkagemap))-1)
}

write.csv(res_df,file="linkagemap_summary.csv")






pdf(file="geno_image_tomato_F2_not_imutated.pdf")
geno.image(dat1)
dev.off()
pdf(file="rf_image_tomato_F2_not_imutated.pdf")
plotRF(dat1)
dev.off()
png(file="rf_image_tomato_F2_not_imutated.png")
plotRF(dat1)
dev.off()

##########QTL analysis
testmapimp <- calc.genoprob(dat1, step=1)

#interval mapping(IM)
pheno_col = 1

for(pheno_col in 1){
  out.simhk <- scanone(testmapimp, pheno.col= pheno_col, method="hk")

  operms <- scanone(testmapimp, n.perm=1000, method="hk",n.cluster=4,pheno.col=pheno_col)
  write.csv( summary(operms), file=paste0("summary_operms_",pheno_col,".csv"))

  write.csv( summary(out.simhk, perms=operms, alpha=0.05, pvalues=TRUE),
             file=paste0("sum_im_qtl",pheno_col,".csv") )

  write.csv(out.simhk,file=paste0("out.simhk.",pheno_col,".csv"))
  
  plot(out.simhk)
  abline(summary(operms)[1],0,col="red" )
  
  pdf(file=paste0("sim_",pheno_col,".pdf"),width=10,height=5)
  plot(out.simhk)
  abline(summary(operms)[1],0,col="red" )
  dev.off()
  
  
  #composite interval mapping(CIM)
  out.cimhk <- cim(testmapimp, n.marcovar=5, pheno.col=pheno_col, method="hk")
  operm <- cim(testmapimp,n.perm=1000,n.marcovar=5,pheno.col = pheno_col, method="hk")
  summary(operm)
  summary(out.cimhk, perms=operm, alpha=0.05, pvalues=TRUE)

  
  plot(out.cimhk)
  abline(summary(operm)[1],0,col="red" )
  
  pdf(file=paste0("Fig2c._cim_",pheno_col,".pdf"),width=10,height=5)
  plot(out.cimhk)
  abline(summary(operm)[1],0,col="red" )
  dev.off()
  
  write.csv( summary(operm), file=paste0("summary_operm_",pheno_col,".csv"))
  

  write.csv(out.cimhk,file=paste0("out.cimhk.",pheno_col,".csv"))
  out.cimhk[out.cimhk$lod > summary(operm)[1] ,  ]
  write.csv( summary(out.cimhk, perms=operm, alpha=0.05, pvalues=TRUE),
             file=paste0("sum_cim_qtl",pheno_col,".csv")  )
  
  #Show IM and CIM results

  
  pdf(file=paste0("qtl_result_f2_",pheno_col,"_not_imputated.pdf") )
  layout(matrix(1:1, ncol=1))
  plot(out.simhk, out.cimhk, col=c("blue", "red"))
  dev.off()
  
  
  res_operms= summary(operms)
  threshold_simhk = out.simhk[out.simhk[,3] > res_operms[1], ]
  threshold_simhk
  
  res_operm= summary(operm)
  threshold_cimhk = out.cimhk[out.cimhk[,3] > res_operm[1], ]
  threshold_cimhk
  
  write.csv(res_operm, file=paste0("res_operm_",pheno_col,".csv"))
  write.csv(res_operms, file=paste0("res_operms_",pheno_col,".csv"))
  write.csv(threshold_cimhk, file=paste0("threshold_cimhk_for_table_",pheno_col,".csv"))
  write.csv(threshold_simhk, file=paste0("threshold_simhk_for_table_",pheno_col,".csv"))

  
  
}


library("ggpubr")
library("scales")
library("cowplot")


#############

###chr01_85983699
chr1_marker= dat1[["geno"]][["01_1"]][["data"]]
chr1_marker[,colnames(chr1_marker) == "chr01_85983699"]
data1= data.frame(chr1_marker[,colnames(chr1_marker) == "chr01_85983699"],
                  dat1[["pheno"]][["pl"]] )

str(data1)
table(data1[,1])
data1[data1[,1] == 1, 1] = "A" 
data1[data1[,1] == 2, 1] = "H"
data1[data1[,1] == 3, 1] = "B"

library(ggpubr)
data1[,1] <-  factor( data1[,1], levels = c("A", "H", "B"))
colnames(data1) = c("chr01_85983699","pl")
gg1 = ggboxplot(data1,x = "chr01_85983699", y="pl",color= "chr01_85983699",
                palette =c("#00AFBB", "#E7B800", "#FC4E07"),
                add = "jitter", shape ="chr01_85983699" )
gg1
ggsave(file="chr01_85983699.pdf", gg1)

library(multcomp)
res_data1<-aov(pl~chr01_85983699,d=data1)
summary(res_data1)
res2_data1<-glht(res_data1,linfct=mcp(chr01_85983699="Tukey"))
summary(res2_data1)
cld(res2_data1)



#####Pat-K####
summary(operm)[1]
df = out.cimhk
data = data.frame(df[df$chr == "01_1",])
data
data2 = data.frame(do.call(rbind, strsplit(rownames(data),"_" ))) 
str(data)
str(data2)
data = cbind(data,data2)
data
data[ data[,4] != "chr01", 5] = NA

write.csv(data,file="data.csv")

colnames(data) = c("chr","cM","LOD","","bp")
data$bp = as.numeric(data$bp)

gg = ggline(data, x = "cM", y = "LOD")
gg

############Genetic_map
QTL_Patk_genetic <- ggpubr::ggscatter(data = data, x = "cM", y = "LOD") +
geom_line() +
ggtitle("QTL chr01")+
theme(axis.text.x = element_text(angle = 90, hjust = 1))

QTL_Patk_genetic = QTL_Patk_genetic + geom_vline( xintercept = data$cM[!is.na(data$bp)], 
                                              color = 1, linetype="solid", size=0.5)+ 
  scale_x_continuous(breaks=seq(65,95,by=1), limits=c(65,95))

#guides(colour=FALSE)

QTL_Patk_genetic


############Physical_map
head(data)
data$Mbp = data$bp/(10^6)

QTL_Patk_physical <- ggpubr::ggscatter(data = data, x = "Mbp", y = "chr") +
  geom_line() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  theme(axis.text.y = element_blank())+
  scale_x_continuous(breaks=seq(81,87.3,by=1), limits=c(81,87.3))
  

QTL_Patk_physical = QTL_Patk_physical + geom_vline( xintercept = data$bp[!is.na(data$bp)]/(10^6),　　 ###これで平均が描かれる
                                              color = 1, linetype="solid", size=0.5)

QTL_Patk_physical = QTL_Patk_physical + geom_vline( xintercept = 85535267/(10^6) ,　　
                                              color = "#FF0000", 
                                              linetype="solid", 
                                              size=0.5)

QTL_Patk_physical





(gg = ggpubr::ggarrange(QTL_Patk_genetic,QTL_Patk_physical , ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="QTL_patk_genetic_physicalmap.pdf",width=8,height=4)


#####phenotype histgram pf F2#####
MPK1  = 104
MicroTom  = 0
F2_pheno = dat1[["pheno"]][["pl"]]

pa_pheno = data.frame(c("MPK1","MicroTom"),c(MPK1, MicroTom))

range(F2_pheno)

library(ggpubr)
###
RColorBrewer::display.brewer.all()

data = data.frame( c( rep("F2",length(F2_pheno)) ) ,F2_pheno)
colnames(data) = c("F2","pl")
phe2 = gghistogram(data , x="pl",
                   #title = paste("DGH"),
                   ylab = "Frequency",
                   xlab = "pl",
                   #size=0.2,
                   binwidth = 2,
                   palette =  c("#edae00") ,
                   color =  "F2", 
                   fill = "F2"  ) 
phe2 = phe2 + ggpubr::font("xy.text",size=10) 
phe2 = phe2 + geom_vline( xintercept =  mean(MicroTom),
                          color = "#ff00ff", linetype="dashed", size=0.5)
phe2 = phe2 + geom_vline( xintercept =  mean(MPK1),
                          color = "#0000ff", linetype="dashed", size=0.5)
phe2 =  ggpubr::ggpar(phe2,
                      font.x = c(10, "bold", "#000000"),
                      font.y = c(10, "bold", "#000000"), 
                      ylab = "Frequency",
                      xlab = "Parthenocarpic level",
                      xlim=c(0,110), ylim = c(0,30)
)　+ theme(legend.position = "none")

phe2 + theme(legend.position="top")
phe2 + theme(legend.position = "none")
phe2


##
d1 = data.frame( c( rep("F2",length(F2_pheno)) ) ,F2_pheno,stringsAsFactors = F)
d2 =  pa_pheno
colnames(d1) = c("Line","pl")
colnames(d2) = c("Line","pl")
data = rbind(d1,d2)

p_for_label = ggpubr::gghistogram(data, 
                                  x = "pl",
                                  #add = "mean", 
                                  #rug = TRUE,
                                  color = "Line", 
                                  fill = "Line",
                                  palette =  c("#edae00", "#0000ff", "#ff00ff"),
                                  binwidth = 1)
library("lemon")
p_legend <- lemon::g_legend(p_for_label)
grid::grid.newpage()
grid::grid.draw(p_legend)
(gg = ggpubr::ggarrange(p_legend,phe2,ncol = 1,nrow = 2, align = "hv") )
ggpubr::ggexport(gg, filename ="pheno_plot_f2.pdf",width=4,height=5)









 