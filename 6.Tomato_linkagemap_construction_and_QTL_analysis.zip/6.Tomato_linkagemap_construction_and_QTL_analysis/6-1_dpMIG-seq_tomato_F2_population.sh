
mkdir bam
mkdir fastq
mkdir reports
mkdir reports_trim

###Merge parental data
cat SL_F2_000K_1_1.fastq.gz SL_F2_000K_2_1.fastq.gz SL_F2_000K_3_1.fastq.gz > SL_F2_000K_1.fastq.gz
cat SL_F2_000M_1_1.fastq.gz SL_F2_000M_2_1.fastq.gz SL_F2_000M_3_1.fastq.gz > SL_F2_000M_1.fastq.gz

cat SL_F2_000K_1_2.fastq.gz SL_F2_000K_2_2.fastq.gz SL_F2_000K_3_2.fastq.gz > SL_F2_000K_2.fastq.gz
cat SL_F2_000M_1_2.fastq.gz SL_F2_000M_2_2.fastq.gz SL_F2_000M_3_2.fastq.gz > SL_F2_000M_2.fastq.gz


SEQLIBS=(SL_F2_000K SL_F2_000M SL_F2_001 SL_F2_002 SL_F2_003 \
SL_F2_004 SL_F2_005 SL_F2_006 SL_F2_007 SL_F2_008 SL_F2_009 SL_F2_010 \
SL_F2_011 SL_F2_012 SL_F2_013 SL_F2_014 SL_F2_015 SL_F2_016 SL_F2_017 \
SL_F2_018 SL_F2_019 SL_F2_020 SL_F2_021 SL_F2_022 SL_F2_023 SL_F2_024 \
SL_F2_025 SL_F2_026 SL_F2_027 SL_F2_028 SL_F2_029 SL_F2_030 SL_F2_031 \
SL_F2_032 SL_F2_033 SL_F2_034 SL_F2_035 SL_F2_036 SL_F2_037 SL_F2_038 \
SL_F2_039 SL_F2_040 SL_F2_041 SL_F2_042 SL_F2_043 SL_F2_044 SL_F2_045 \
SL_F2_046 SL_F2_047 SL_F2_048 SL_F2_049 SL_F2_050 SL_F2_051 SL_F2_052 \
SL_F2_053 SL_F2_054 SL_F2_055 SL_F2_056 SL_F2_057 SL_F2_058 SL_F2_059 \
SL_F2_060 SL_F2_061 SL_F2_062 SL_F2_063 SL_F2_064 SL_F2_065 SL_F2_066 \
SL_F2_067 SL_F2_068 SL_F2_069 SL_F2_070 SL_F2_071 SL_F2_072 SL_F2_073 \
SL_F2_074 SL_F2_075 SL_F2_076 SL_F2_077 SL_F2_078 SL_F2_079 SL_F2_080 \
SL_F2_081 SL_F2_082 SL_F2_083 SL_F2_084 SL_F2_085 SL_F2_086 SL_F2_087 \
SL_F2_088 SL_F2_089 SL_F2_090 SL_F2_091 SL_F2_092 SL_F2_093 SL_F2_094)

for seqlib in ${SEQLIBS[@]}; do
fastqc --nogroup -o ./reports rawdata/${seqlib}_1.fastq.gz
fastqc --nogroup -o ./reports rawdata/${seqlib}_2.fastq.gz
done
cd reports
multiqc .
cd ../

##Trimming by trimmomatic
for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/${seqlib}_1.fastq.gz rawdata/${seqlib}_2.fastq.gz \
fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_unpaired_output_1.fq \
fastq/${seqlib}_paired_output_2.fq fastq/${seqlib}_unpaired_output_2.fq \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
done

for seqlib in ${SEQLIBS[@]}; do
fastqc --nogroup -o ./reports_trim fastq/${seqlib}_paired_output_1.fq
fastqc --nogroup -o ./reports_trim fastq/${seqlib}_paired_output_2.fq
done

cd reports_trim
multiqc .
cd ../

thread=12

REF=../ref/tomato/tomato_ref.fasta
for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M -o ${seqlib}.sam \
$REF fastq/${seqlib}_paired_output_1.fq fastq/${seqlib}_paired_output_2.fq
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
done

###samtools mpileup
samtools mpileup -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
-v bam/*.sorted.bam \
 | bcftools call -c -v -o SL_F2_samtools.vcf

 vcftools --vcf SL_F2_samtools.vcf --max-missing 0.90 --minDP 5 --maf 0.20 \
 --minQ 20 --min-alleles 2 --max-alleles 2 \
 --recode --recode-INFO-all --out filtered_SL_F2_samtools.vcf


####
CHRS=(NC_015438.3 NC_015447.3 NC_015448.3 NC_015449.3 NC_015439.3 NC_015440.3 \
NC_015441.3 NC_015442.3 NC_015443.3 NC_015444.3 NC_015445.3 NC_015446.3)
for chr in ${CHRS[@]}; do
mkdir ${chr}
vcftools --vcf filtered_SL_F2_samtools.vcf.recode.vcf --chr ${chr} \
--recode --recode-INFO-all --out ${chr}/${chr}.samtools.vcf
java -cp Lep-MAP3/bin ParentCall2 data = pedigree.txt  vcfFile = ${chr}/${chr}.samtools.vcf.recode.vcf > ${chr}/p.call
java -cp Lep-MAP3/bin Filtering2 data=${chr}/p.call  removeNonInformative=1 dataTolerance=0.000001   > ${chr}/p_fil.call
java -cp Lep-MAP3/bin  SeparateChromosomes2 data=${chr}/p_fil.call lodLimit=5 numThreads=6 > ${chr}/map.txt
sort ${chr}/map.txt|uniq -c|sort -n
done

for chr in ${CHRS[@]}; do
java -cp Lep-MAP3/bin  OrderMarkers2 data=${chr}/p_fil.call map=${chr}/map.txt sexAveraged=1 \
grandparentPhase=1 numThreads=6 outputPhasedData=1  > ${chr}/order.txt
#java -cp $PA/Lep-MAP3/bin  OrderMarkers2 evaluateOrder=${chr}/order.txt data=${chr}/p_fil.call improveOrder=0 sexAveraged=1 > ${chr}/order1.SA.txt
cut -f1,2 ${chr}/p_fil.call > ${chr}/cut_p_fil.call.txt
awk -v fullData=1 -f map2genotypes.awk ${chr}/order.txt > ${chr}/genotypes.${chr}.txt
done
