
####MIG-seq_dpMIG-seq_parents
mkdir bam
mkdir vcf
mkdir fastq

cat rawdata/TN26/MIG_PS1/*_1.fastq.gz > rawdata/TN26_m_1.fastq.gz
cat rawdata/TN26/MIG_PS1/*_2.fastq.gz > rawdata/TN26_m_2.fastq.gz
cat rawdata/ST/MIG_PS1/*_1.fastq.gz   > rawdata/ST_m_1.fastq.gz
cat rawdata/ST/MIG_PS1/*_2.fastq.gz   > rawdata/ST_m_2.fastq.gz

cat rawdata/TN26/dpMIG_PS1_45/*_1.fastq.gz > rawdata/TN26_4n5n_1.fastq.gz
cat rawdata/TN26/dpMIG_PS1_45/*_2.fastq.gz > rawdata/TN26_4n5n_2.fastq.gz
cat rawdata/ST/dpMIG_PS1_45/*_1.fastq.gz   > rawdata/ST_4n5n_1.fastq.gz
cat rawdata/ST/dpMIG_PS1_45/*_2.fastq.gz   > rawdata/ST_4n5n_2.fastq.gz


seqkit stat rawdata/TN26_m_1.fastq.gz rawdata/TN26_m_2.fastq.gz rawdata/ST_m_1.fastq.gz rawdata/ST_m_2.fastq.gz > m_stat.tsv
seqkit stat rawdata/TN26_4n5n_1.fastq.gz rawdata/TN26_4n5n_2.fastq.gz rawdata/ST_4n5n_1.fastq.gz rawdata/ST_4n5n_2.fastq.gz > m4n5n_stat.tsv


###Specify the path of reference genome of durum wheat

SEQLIBS=(TN26_m ST_m TN26_4n5n ST_4n5n)
REF=../ref/tetraploid_wheat/durum_genome.fasta
thread=14

for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/${seqlib}_1.fastq.gz  rawdata/${seqlib}_2.fastq.gz fastq/${seqlib}_paired_output_1.fq.gz \
fastq/${seqlib}_unpaired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz fastq/${seqlib}_unpaired_output_2.fq.gz \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M\
 -o ${seqlib}.sam  $REF\
  fastq/${seqlib}_paired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -c -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

####Variant calling for MIG-seq data of ST and TN26
REF=../ref/tetraploid_wheat/durum_genome.fasta
samtools mpileup -d 0  -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/ST_m.sorted.bam bam/TN26_m.sorted.bam \
  | bcftools call -c -v -o m_samtools.vcf

####Variant calling for dpMIG-seq:PS14:5 data of ST and TN26
REF=../ref/tetraploid_wheat/durum_genome.fasta
samtools mpileup -d 0 -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP \
 -v bam/ST_4n5n.sorted.bam bam/TN26_4n5n.sorted.bam \
  | bcftools call -c -v -o m4n5n_samtools.vcf



#####Application of MIG-seq and dp@MIG-seq to selection of backcross lines

########Mapping of MIG-seq data of BC4F2 population
SEQLIBS=(B42_001_m B42_002_m B42_003_m B42_004_m B42_005_m B42_006_m \
B42_007_m B42_008_m B42_009_m B42_010_m B42_011_m B42_012_m \
B42_013_m B42_014_m B42_015_m B42_016_m)
REF=../ref/tetraploid_wheat/durum_genome.fasta

for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/${seqlib}_1.fastq.gz  rawdata/${seqlib}_2.fastq.gz fastq/${seqlib}_paired_output_1.fq.gz \
fastq/${seqlib}_unpaired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz fastq/${seqlib}_unpaired_output_2.fq.gz \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M\
 -o ${seqlib}.sam  $REF\
  fastq/${seqlib}_paired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -c -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

REF=../ref/tetraploid_wheat/durum_genome.fasta
samtools mpileup -d 0  -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP  \
 -v bam/ST_m.sorted.bam bam/TN26_m.sorted.bam bam/B42*m.sorted.bam \
  | bcftools call -c -v -o BC4F2_m_samtools.vcf

########Mapping of BC4F2 population
SEQLIBS=(B43_32_m)
##refference
REF=../ref/tetraploid_wheat/durum_genome.fasta
thread=2

for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/BC4F3/MIG_PS1/${seqlib}_1.fastq.gz  rawdata/BC4F3/MIG_PS1/${seqlib}_2.fastq.gz fastq/${seqlib}_paired_output_1.fq.gz \
fastq/${seqlib}_unpaired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz fastq/${seqlib}_unpaired_output_2.fq.gz \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M\
 -o ${seqlib}.sam  $REF\
  fastq/${seqlib}_paired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -c -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

REF=../ref/tetraploid_wheat/durum_genome.fasta
samtools mpileup -d 0  -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP  \
 -v bam/ST_m.sorted.bam bam/TN26_m.sorted.bam bam/B43_32_m.sorted.bam \
  | bcftools call -c -v -o BC4F3_m_samtools.vcf



########BC4F3_dpMIG-seq:4-5
cat rawdata/BC4F3/dpMIG_PS1_45/B43_32*_1.fastq.gz > rawdata/B43_32_4n5n_1.fastq.gz
cat rawdata/BC4F3/dpMIG_PS1_45/B43_32*_2.fastq.gz > rawdata/B43_32_4n5n_2.fastq.gz

SEQLIBS=(B43_32_4n5n)
REF=../ref/tetraploid_wheat/durum_genome.fasta
thread=2

for seqlib in ${SEQLIBS[@]}; do
trimmomatic PE -threads 4 -phred33  rawdata/${seqlib}_1.fastq.gz  rawdata/${seqlib}_2.fastq.gz fastq/${seqlib}_paired_output_1.fq.gz \
fastq/${seqlib}_unpaired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz fastq/${seqlib}_unpaired_output_2.fq.gz \
HEADCROP:17 ILLUMINACLIP:TruSeq3-PE-2.fa:2:30:10 LEADING:20 TRAILING:20 SLIDINGWINDOW:4:15
done

for seqlib in ${SEQLIBS[@]}; do
bwa mem -R "@RG\tID:FLOWCELLID\tSM:${seqlib}\tPL:illumina\tLB:${seqlib}_library_1" -t $thread -M\
 -o ${seqlib}.sam  $REF\
  fastq/${seqlib}_paired_output_1.fq.gz fastq/${seqlib}_paired_output_2.fq.gz
samtools view -@ $thread -bS ${seqlib}.sam > bam/${seqlib}.bam
samtools sort -@ $thread -o bam/${seqlib}.sorted.bam bam/${seqlib}.bam
samtools index -c -@ $thread bam/${seqlib}.sorted.bam
rm ${seqlib}.sam
rm bam/${seqlib}.bam
done

REF=../ref/tetraploid_wheat/durum_genome.fasta
samtools mpileup -d 0  -uf $REF -t AD,INFO/AD,DP,DV,DPR,INFO/DPR,DP,DP4,SP  \
 -v bam/ST_4n5n.sorted.bam bam/TN26_4n5n.sorted.bam bam/B43_32_4n5n.sorted.bam \
  | bcftools call -c -v -o BC4F3_4n5n_samtools.vcf



#####Filtering vcf files
vcftools --vcf m_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_m_samtools.vcf

vcftools --vcf m4n5n_samtools.vcf --max-missing 1 --minDP 1 \
--recode --recode-INFO-all --out filtered_m4n5n_samtools.vcf

vcftools --vcf BC4F2_m_samtools.vcf --max-missing 0.8 --minDP 10 \
--recode --recode-INFO-all --out filtered_BC4F2_m_samtools.vcf

vcftools --vcf BC4F3_m_samtools.vcf --max-missing 1 --minDP 10 \
--recode --recode-INFO-all --out filtered_BC4F3_m_samtools.vcf

vcftools --vcf BC4F3_4n5n_samtools.vcf --max-missing 1 --minDP 10 \
--recode --recode-INFO-all --out filtered_BC4F3_4n5n_samtools.vcf

######Variantcallin using gatk
SEQLIBS=(TN26_m ST_m TN26_4n5n ST_4n5n B42_001_m B42_002_m B42_003_m B42_004_m B42_005_m B42_006_m \
B42_007_m B42_008_m B42_009_m B42_010_m B42_011_m B42_012_m \
B42_013_m B42_014_m B42_015_m B42_016_m B43_32_m B43_32_4n5n)

######If it takes too long, run in parallel using multiple terminals
SEQLIBS=(B42_001_m B42_002_m B42_003_m B42_004_m)
SEQLIBS=(B42_005_m B42_006_m B42_007_m B42_008_m)
SEQLIBS=(B42_009_m B42_010_m B42_011_m B42_012_m)
SEQLIBS=(B42_013_m B42_014_m B42_015_m B42_016_m)
SEQLIBS=(B43_32_m B43_32_4n5n)
SEQLIBS=(ST_m)
SEQLIBS=(TN26_4n5n)
SEQLIBS=(ST_4n5n)

REF=../ref/tetraploid_wheat/durum_genome.fasta
for seqlib in ${SEQLIBS[@]}; do
gatk HaplotypeCaller -R $REF\
 -I bam/${seqlib}.sorted.bam -O vcf/${seqlib}.g.vcf --emit-ref-confidence GVCF
done

for seqlib in ${SEQLIBS[@]}; do
gatk IndexFeatureFile -I vcf/${seqlib}.g.vcf
done



echo -e "ENA|LT934111|LT934111.1\nENA|LT934113|LT934113.1\nENA|LT934115|LT934115.1\nENA|LT934117|LT934117.1\nENA|LT934119|LT934119.1\nENA|LT934121|LT934121.1\nENA|LT934123|LT934123.1\nENA|LT934112|LT934112.1\nENA|LT934114|LT934114.1\nENA|LT934116|LT934116.1\nENA|LT934118|LT934118.1\nENA|LT934120|LT934120.1\nENA|LT934122|LT934122.1\nENA|LT934124|LT934124.1" > intervals_4x.list

##BC4F2
gatk GenomicsDBImport \
    --genomicsdb-workspace-path my_database_BC4F2 \
     -L intervals_4x.list\
     --sample-name-map sample_map_m_BC4F2.txt \
REF=../ref/tetraploid_wheat/durum_genome.fasta
gatk GenotypeGVCFs \
       -R $REF \
       -V gendb://my_database_BC4F2 \
       -O mig_BC4F2_output.vcf

#B4F3_MIG
gatk GenomicsDBImport \
    --genomicsdb-workspace-path my_database_BC4F3 \
     -L intervals_4x.list\
     --sample-name-map sample_map_m_BC4F3.txt
REF=../ref/tetraploid_wheat/durum_genome.fasta
gatk GenotypeGVCFs \
       -R $REF \
       -V gendb://my_database_BC4F3 \
       -O mig_BC4F3_output.vcf


#B4F3_dpMIG
gatk GenomicsDBImport \
    --genomicsdb-workspace-path my_database_dpMIG_BC4F3 \
     -L intervals_4x.list\
     --sample-name-map sample_map_4n5n_BC4F3.txt
REF=../ref/tetraploid_wheat/durum_genome.fasta
gatk GenotypeGVCFs \
       -R $REF \
       -V gendb://my_database_dpMIG_BC4F3 \
       -O mig_dpMIG_BC4F3_output.vcf
       
vcftools --vcf mig_BC4F2_output.vcf --max-missing 0.8 --minDP 10 \
--recode --recode-INFO-all --out filtered_mig_BC4F2_output.vcf

vcftools --vcf mig_BC4F3_output.vcf --max-missing 1 --minDP 10 \
--recode --recode-INFO-all --out filtered_mig_BC4F3_output.vcf

vcftools --vcf mig_dpMIG_BC4F3_output.vcf --max-missing 1 --minDP 10 \
--recode --recode-INFO-all --out filtered_mig_dpMIG_BC4F3_output.vcf


