
require(vcfR)
require(qqman)

####BC4F2 MIG-seq####
# read compressed vcf file (*.vcf.gz)
vcf <- read.vcfR("filtered_mig_BC4F2_output.vcf.recode.vcf")

# extract genotype data from vcf
gt = extract.gt(vcf)

gt[1:10,]
dim(gt)

# extract depyh data from vcf
dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
dp[1:10,]


# get marker information (chromosone numbers and positions)
chrom <- getCHROM(vcf)
pos <- getPOS(vcf)

#show the first 10 SNPs of the first 10 lines 
gt[1:10, ]

# create a matrix of gt scores
gt.score <- matrix(NA, nrow(gt), ncol(gt))
gt.score[gt == "0/0"] <- -1
gt.score[gt == "0/1"] <- 0
gt.score[gt == "1/1"] <- 1
gt.score[gt == "0|0"] <- -1
gt.score[gt == "0|1"] <- 0
gt.score[gt == "1|1"] <- 1

gt.score[1:10,]

dim(gt.score)
str(gt.score)

# name the rows and columns of matrix
rownames(gt.score) <- rownames(gt)
colnames(gt.score) <- colnames(gt)
gt.score[1:10, 1]

#filtering by depth
#set parameter
#b =10
FilterbyDP = function(b){
  
  filter_dp_progeny = b
  
  dp_pro = dp
  colnames(dp_pro)
  
  gt.score_pro = gt.score
  
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  
  gt.score_filtered = gt.score_pro
  
  all_data = data.frame(chrom,pos,gt.score_filtered)
  
  str(all_data)
  
  return(all_data)
}


hist(dp)

dp_sum = apply(dp,1,sum)

length(dp_sum)
length(pos)
length(chrom)

dp_limit = 10

all_data = FilterbyDP(dp_limit)
all_data[1:10,]
dim(all_data)

#extracted hoge% typing loci
df = as.data.frame(all_data)

p1=2+ 17
p2=2+ 18

df2 = df[  !is.na(df[,p1]) &
             !is.na(df[,p2]) 
           &  df[,p1] != 0  
           &  df[,p2] != 0 
           &  df[,p1] != df[,p2]
           , ]

df2[1:10,]
dim(df2)

pos1 =   as.numeric(
  as.character(
    df2$pos) ) 

pos2 =   as.numeric(
  (as.character( 
    c(0, pos1[1:(length(pos1)-1)]))))


pos_dist = pos1 - pos2


pos_dist 


df3 = df2[ pos_dist > 500 | pos_dist < 0,]
dim(df3)


dp_m = apply(dp,1,mean)


dp2 = dp_m[   !is.na(df[,p1]) &
                !is.na(df[,p2]) 
              &            df[,p1] != 0  
              &           df[,p2] != 0 
              &  df[,p1] != df[,p2]
]



df_mat = data.frame( as.numeric(as.factor( df2$chrom) )  ,as.numeric(as.character(df2$pos)),dp2+1, "G" ,
                     stringsAsFactors = F)

str(df_mat)

colnames(df_mat) = c("ch","pos","dp","snp")


manhattan(df_mat, chr = "ch", 
          bp = "pos", 
          p = "dp", 
          snp = "snp",
          logp =F,
          suggestiveline =F ,
          genomewideline = F,
          ylim = c(0,500)) 



pdf(file="snp_mat_BC2_BC3.pdf")
manhattan(df_mat, chr = "ch", 
          bp = "pos", 
          p = "dp", 
          snp = "snp",
          logp =F,
          suggestiveline =F ,
          genomewideline = F,
          ylim = c(0,5000))
dev.off()


dim(df2)
dim(df3)
df2

df_BC4F2 = df2[,c(1:2,19:20,3:18)]

df_BC4F2

#Convert ABH genotype
gt_table = df_BC4F2[,3:ncol(df_BC4F2)]
gt_table[1:10,]

for(j in 1:nrow(gt_table)){
  for_message =paste0(j)
  message(for_message)
  
  d = as.character(gt_table[j,])
  d =  sub(d[1],"A",d) 
  d =  sub(d[2],"B",d) 
  d =  sub("0","H",d) 
  #d =  sub("0","-",d) 
  gt_table[j,] = d
}
gt_table[1:10,]

gt_table[is.na(gt_table)] = "-"
gt_table[1:12,]
dim(gt_table)
write.csv(cbind(as.numeric(as.factor(df_BC4F2$chrom)),df_BC4F2$pos ,gt_table),file=paste0("ABH_geno_",dp_limit,"_BC4F2.csv") )

table(df_BC4F2[,3])
table(df_BC4F2[,4])

i=5

colnames(df_BC4F2)




for(i in 1:16){
  res_table = table(gt_table[,i])
}

######Plot marker positions for each chromosome####

ref_fai = read.table(file="durum_genome.fasta.fai")

group.names = c( "chr1A",
                 "chr2A","chr3A",
                 "chr4A","chr5A",
                 "chr6A","chr7A",
                 "chr1B","chr2B", 
                 "chr3B","chr4B",
                 "chr5B", 
                 "chr6B", "chr7B")


group.names = c( "1A","1B","2A","2B","3A","3B",
                 "4A","4B","5A","5B",
                 "6A","6B","7A","7B")

chr_length = ref_fai$V2[c(1,8,2,9,3,10,4,11,5,12,6,13,7,14 )]
library(RColorBrewer)
display.brewer.all()
df_pop = df_BC4F2

MAX_chr = max(chr_length)/10^6
for(n in 3:ncol(gt_table)){
  plot_geno     = gt_table[,n]
  
  message(paste0(colnames(gt_table)[n]))
  
  
  plot_chr_num  = as.numeric(as.factor( df_pop$chrom) )
  plot_pos      = df_pop$pos
  dat <- structure(list(chromosome =group.names ,chr_length/10^6)
                   , .Names = c("chromosome","size"), 
                   class = "data.frame", row.names = c(NA, -14L)) 
  
  marks <- structure(list(Chromosome = plot_chr_num, 
                          Position = plot_pos/10^6, 
                          Type = structure(as.factor(plot_geno), 
                                           .Label = c("-","A", "B","H"), class = "factor")), 
                     .Names = c("Chromosome","Position", "Type"), 
                     class = "data.frame", row.names = c(NA,-length(plot_chr_num) ))
  
  
  cols = c("#ffffff", "#3cb371", "#ffff00","#000080")
  
  marks_Type = as.numeric(marks$Type)
  
  for(i in 1:4){
    marks_Type[marks_Type == i] =  cols[i]
  }
  marks_Type
  
  
  pdf(file=paste0("chr_geno_plot_",colnames(gt_table)[n],".pdf") ,width=8,height=4)
  
  par(mar=c(3,6,3,6))
  bp <- barplot(dat$size, border=NA, col="grey80" , names.arg=group.names,
                main= colnames(gt_table)[n],
                ylab = "Physical position (Mb)", 
                ylim = c(MAX_chr,0) )
  
  
  with(marks,
       segments(
         bp[Chromosome,]-0.5,
         Position,
         bp[Chromosome,]+0.5,
         Position,
         col= marks_Type,
         lwd=2, 
         lend=1
       )
  )
  
  qtl = structure(list(Chromosome = c(13), 
                       Position = c(69359051/10^6), 
                       Type = structure(2, 
                                        .Label = c("VRN-A3"), class = "factor")), 
                  .Names = c("Chromosome","Position", "Type"), 
                  class = "data.frame", row.names = c(NA,-1L ))
  
  with(qtl,
       segments(
         bp[Chromosome,]-0.5,
         Position,
         bp[Chromosome,]+0.5,
         Position,
         col=c("#ff0000","#ff0016" ),
         lwd=2, 
         lend=1
       )
  )
  
  par(xpd=T)
  legend(par()$usr[2], par()$usr[4],
         legend=c( "-","A","B","H","VRN-A3","HI_QTL"), 
         pch = 15, col=c(cols,"#ff0000","#ff0016" ))
  dev.off()
  
}


###########Detection of heterozygous loci in BC4F1 generation
df = read.csv(file= "ABH_geno_10_BC4F2.csv")

df[df == "-"] = NA

#x = c("A","A","B","H",NA)

chi_allele= function(x){
  y = x[!is.na(x)]
  
  if(length(y)>0 ){
    y_t = table( c("A","H","B",y) ) -1 
    res=chisq.test(x=c(y_t),p= c(0.25,0.25,0.5))
    return( res[["p.value"]] )
    
  }else{
    return( NA )
    
  }
  
}

res_chi= apply(  df[,6:21],1,chi_allele)

res_manhattan = data.frame(df[,2:3], 1/-log10(res_chi))
res_manhattan = data.frame(df[,2:3], res_chi)


data=res_manhattan 
colnames(data) = c("chr","pos","p")

data$pos = data$pos/(10^6)


library(ggpubr)


chr_list = c("Chr1A","Chr1B","Chr2A","Chr2B","Chr3A","Chr3B","Chr4A",
             "Chr4B","Chr5A","Chr5B","Chr6A","Chr6B","Chr7A","Chr7B")

i=1
for(i in 1:14){
  data2 = data[data$chr == i,]
  gg = ggscatter(data2, x="pos", y = "p")+
    scale_y_continuous(breaks=seq(0,1,length=5),limits=c(0,1))+
    labs(title=chr_list[i],x="Physical position (Mbp)", y="p value")+
    geom_line()
  
  assign( paste0("gg",i),gg)
}



ggar = ggarrange(gg1,gg2,gg3,gg4,gg5,gg6,gg7,
                 gg8,gg9,gg10,gg11,gg12,gg13,gg14,nrow = 4,ncol=4)

ggsave(ggar, file= "20220720_chi.pdf",height=12,width=12)



####BC4F3 MIG-seq#####
# read compressed vcf file (*.vcf.gz)
vcf <- read.vcfR("filtered_mig_BC4F3_output.vcf.recode.vcf")

# extract genotype data from vcf
gt = extract.gt(vcf)

gt[1:10,]
dim(gt)

# extract depyh data from vcf
dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
dp[1:10,]


# get marker information (chromosone numbers and positions)
chrom <- getCHROM(vcf)
pos <- getPOS(vcf)

#show the first 10 SNPs of the first 10 lines 
gt[1:10, ]

# create a matrix of gt scores
gt.score <- matrix(NA, nrow(gt), ncol(gt))
gt.score[gt == "0/0"] <- -1
gt.score[gt == "0/1"] <- 0
gt.score[gt == "1/1"] <- 1
gt.score[gt == "0|0"] <- -1
gt.score[gt == "0|1"] <- 0
gt.score[gt == "1|1"] <- 1

gt.score[1:10,]

dim(gt.score)
str(gt.score)

# name the rows and columns of matrix
rownames(gt.score) <- rownames(gt)
colnames(gt.score) <- colnames(gt)
gt.score[1:10, 1]

#filtering by depth
#set parameter
#b =10
FilterbyDP = function(b){
  
  filter_dp_progeny = b
  
  dp_pro = dp
  colnames(dp_pro)
  
  gt.score_pro = gt.score
  
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  
  gt.score_filtered = gt.score_pro
  
  all_data = data.frame(chrom,pos,gt.score_filtered)
  
  str(all_data)
  
  return(all_data)
}


hist(dp)

dp_sum = apply(dp,1,sum)

length(dp_sum)
length(pos)
length(chrom)

dp_limit = 10

all_data = FilterbyDP(dp_limit)
all_data[1:10,]
dim(all_data)

#extracted hoge% typing loci
df = as.data.frame(all_data)

p1=2+ 1
p2=2+ 2

df2 = df[  !is.na(df[,p1]) &
             !is.na(df[,p2]) 
           &  df[,p1] != 0  
           &  df[,p2] != 0 
           &  df[,p1] != df[,p2]
           , ]

df2[1:10,]
dim(df2)

pos1 =   as.numeric(
  as.character(
    df2$pos) ) 

pos2 =   as.numeric(
  (as.character( 
    c(0, pos1[1:(length(pos1)-1)]))))


pos_dist = pos1 - pos2


pos_dist 


df3 = df2[ pos_dist > 500 | pos_dist < 0,]
dim(df3)


dp_m = apply(dp,1,mean)


dp2 = dp_m[   !is.na(df[,p1]) &
                !is.na(df[,p2]) 
              &            df[,p1] != 0  
              &           df[,p2] != 0 
              &  df[,p1] != df[,p2]
]



df_mat = data.frame( as.numeric(as.factor( df2$chrom) )  ,as.numeric(as.character(df2$pos)),dp2+1, "G" ,
                     stringsAsFactors = F)

str(df_mat)

colnames(df_mat) = c("ch","pos","dp","snp")


manhattan(df_mat, chr = "ch", 
          bp = "pos", 
          p = "dp", 
          snp = "snp",
          logp =F,
          suggestiveline =F ,
          genomewideline = F,
          ylim = c(0,500)) 



pdf(file="snp_mat_BC2_BC3.pdf")
manhattan(df_mat, chr = "ch", 
          bp = "pos", 
          p = "dp", 
          snp = "snp",
          logp =F,
          suggestiveline =F ,
          genomewideline = F,
          ylim = c(0,5000))
dev.off()


dim(df2)
dim(df3)

df2

df_BC4F2 = df2[,c(1:2,3 ,4,5)]

df_BC4F2

#Convert ABH genotype
gt_table = data.frame(df_BC4F2[,3:5])

for(j in 1:nrow(gt_table)){
  for_message =paste0(j)
  message(for_message)
  
  d = as.character(gt_table[j,])
  d =  sub(d[1],"A",d) 
  d =  sub(d[2],"B",d) 
  d =  sub("0","H",d) 
  #d =  sub("0","-",d) 
  gt_table[j,] = d
}
gt_table[1:10,]

gt_table[is.na(gt_table)] = "-"
gt_table[1:12,]
dim(gt_table)
write.csv(cbind(as.numeric(as.factor(df_BC4F2$chrom)),df_BC4F2$pos ,gt_table),file=paste0("ABH_geno_",dp_limit,"_BC4F2.csv") )

table(df_BC4F2[,3])

i=5

for(i in 1){
  res_table = table(gt_table[,i])
}

######Plot marker positions for each chromosome####

ref_fai = read.table(file="durum_genome.fasta.fai")

group.names = c( "chr1A",
                 "chr2A","chr3A",
                 "chr4A","chr5A",
                 "chr6A","chr7A",
                 "chr1B","chr2B", 
                 "chr3B","chr4B",
                 "chr5B", 
                 "chr6B", "chr7B")


group.names = c( "1A","1B","2A","2B","3A","3B",
                 "4A","4B","5A","5B",
                 "6A","6B","7A","7B")

chr_length = ref_fai$V2[c(1,8,2,9,3,10,4,11,5,12,6,13,7,14 )]
library(RColorBrewer)
display.brewer.all()
df_pop = df_BC4F2

MAX_chr = max(chr_length)/10^6
for(n in 3){
  plot_geno     = gt_table[,n]
  
  message(paste0(colnames(gt_table)[n]))
  
  
  plot_chr_num  = as.numeric(as.factor( df_pop$chrom) )
  plot_pos      = df_pop$pos
  dat <- structure(list(chromosome =group.names ,chr_length/10^6)
                   , .Names = c("chromosome","size"), 
                   class = "data.frame", row.names = c(NA, -14L)) 
  
  marks <- structure(list(Chromosome = plot_chr_num, 
                          Position = plot_pos/10^6, 
                          Type = structure(as.factor(plot_geno), 
                                           .Label = c("A", "B","H","-"), class = "factor")), 
                     .Names = c("Chromosome","Position", "Type"), 
                     class = "data.frame", row.names = c(NA,-length(plot_chr_num) ))
  
  
  cols = c( "#3cb371", "#ffff00","#000080","#ffffff")
  
  marks_Type = as.numeric(marks$Type)
  
  for(i in 1:4){
    marks_Type[marks_Type == i] =  cols[i]
  }
  marks_Type
  
  
  pdf(file=paste0("chr_geno_plot_",colnames(gt_table)[n],".pdf") ,width=8,height=4)
  
  par(mar=c(3,6,3,6))
  bp <- barplot(dat$size, border=NA, col="grey80" , names.arg=group.names,
                main= colnames(gt_table)[n],
                ylab = "Physical position (Mb)", 
                ylim = c(MAX_chr,0) )
  
  
  with(marks,
       segments(
         bp[Chromosome,]-0.5,
         Position,
         bp[Chromosome,]+0.5,
         Position,
         col= marks_Type,
         lwd=2, 
         lend=1
       )
  )
  
  qtl = structure(list(Chromosome = c(13), 
                       Position = c(69359051/10^6), 
                       Type = structure(2, 
                                        .Label = c("VRN-A3"), class = "factor")), 
                  .Names = c("Chromosome","Position", "Type"), 
                  class = "data.frame", row.names = c(NA,-1L ))
  
  with(qtl,
       segments(
         bp[Chromosome,]-0.5,
         Position,
         bp[Chromosome,]+0.5,
         Position,
         col=c("#ff0000" ),
         lwd=2, 
         lend=1
       )
  )
  
  par(xpd=T)
  legend(par()$usr[2], par()$usr[4],
         legend=c("A","B","H","-","VRN-A3"), 
         pch = 15, col=c(cols,"#ff0000" ))
  dev.off()
  
}


############BC4F3 dpMIG-seq#####
# read compressed vcf file (*.vcf.gz)
vcf <- read.vcfR("filtered_mig_dpMIG_BC4F3_output.vcf.recode.vcf")

# extract genotype data from vcf
gt = extract.gt(vcf)

gt[1:10,]
dim(gt)

# extract depyh data from vcf
dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
dp[1:10,]


# get marker information (chromosone numbers and positions)
chrom <- getCHROM(vcf)
pos <- getPOS(vcf)

#show the first 10 SNPs of the first 10 lines 
gt[1:10, ]

# create a matrix of gt scores
gt.score <- matrix(NA, nrow(gt), ncol(gt))
gt.score[gt == "0/0"] <- -1
gt.score[gt == "0/1"] <- 0
gt.score[gt == "1/1"] <- 1
gt.score[gt == "0|0"] <- -1
gt.score[gt == "0|1"] <- 0
gt.score[gt == "1|1"] <- 1

gt.score[1:10,]

dim(gt.score)
str(gt.score)

# name the rows and columns of matrix
rownames(gt.score) <- rownames(gt)
colnames(gt.score) <- colnames(gt)
gt.score[1:10, 1]

#filtering by depth
#set parameter
#b =10
FilterbyDP = function(b){
  
  filter_dp_progeny = b
  
  dp_pro = dp
  colnames(dp_pro)
  
  gt.score_pro = gt.score
  
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  
  gt.score_filtered = gt.score_pro
  
  all_data = data.frame(chrom,pos,gt.score_filtered)
  
  str(all_data)
  
  return(all_data)
}


hist(dp)

dp_sum = apply(dp,1,sum)

length(dp_sum)
length(pos)
length(chrom)

dp_limit = 10

all_data = FilterbyDP(dp_limit)
all_data[1:10,]
dim(all_data)

#extracted hoge% typing loci
df = as.data.frame(all_data)

p1=2+ 1
p2=2+ 2

df2 = df[  !is.na(df[,p1]) &
             !is.na(df[,p2]) 
           &  df[,p1] != 0  
           &  df[,p2] != 0 
           &  df[,p1] != df[,p2]
           , ]

df2[1:10,]
dim(df2)

pos1 =   as.numeric(
  as.character(
    df2$pos) ) 

pos2 =   as.numeric(
  (as.character( 
    c(0, pos1[1:(length(pos1)-1)]))))


pos_dist = pos1 - pos2


pos_dist 


df3 = df2[ pos_dist > 500 | pos_dist < 0,]
dim(df3)


dp_m = apply(dp,1,mean)


dp2 = dp_m[   !is.na(df[,p1]) &
                !is.na(df[,p2]) 
              &            df[,p1] != 0  
              &           df[,p2] != 0 
              &  df[,p1] != df[,p2]
]



df_mat = data.frame( as.numeric(as.factor( df2$chrom) )  ,as.numeric(as.character(df2$pos)),dp2+1, "G" ,
                     stringsAsFactors = F)

str(df_mat)

colnames(df_mat) = c("ch","pos","dp","snp")


manhattan(df_mat, chr = "ch", 
          bp = "pos", 
          p = "dp", 
          snp = "snp",
          logp =F,
          suggestiveline =F ,
          genomewideline = F,
          ylim = c(0,500)) 



pdf(file="snp_mat_BC2_BC3.pdf")
manhattan(df_mat, chr = "ch", 
          bp = "pos", 
          p = "dp", 
          snp = "snp",
          logp =F,
          suggestiveline =F ,
          genomewideline = F,
          ylim = c(0,5000))
dev.off()


dim(df2)
dim(df3)

df2

df_BC4F2 = df2[,c(1:2,3 ,4,5)]

df_BC4F2

#Convert ABH genotype
gt_table = data.frame(df_BC4F2[,3:5])

for(j in 1:nrow(gt_table)){
  for_message =paste0(j)
  message(for_message)
  
  d = as.character(gt_table[j,])
  d =  sub(d[1],"A",d) 
  d =  sub(d[2],"B",d) 
  d =  sub("0","H",d) 
  #d =  sub("0","-",d) 
  gt_table[j,] = d
}
gt_table[1:10,]

gt_table[is.na(gt_table)] = "-"
gt_table[1:12,]
dim(gt_table)
write.csv(cbind(as.numeric(as.factor(df_BC4F2$chrom)),df_BC4F2$pos ,gt_table),file=paste0("ABH_geno_",dp_limit,"_BC4F2.csv") )

table(df_BC4F2[,3])

i=5

for(i in 1){
  res_table = table(gt_table[,i])
}

######Plot marker positions for each chromosome####

ref_fai = read.table(file="durum_genome.fasta.fai")

group.names = c( "chr1A",
                 "chr2A","chr3A",
                 "chr4A","chr5A",
                 "chr6A","chr7A",
                 "chr1B","chr2B", 
                 "chr3B","chr4B",
                 "chr5B", 
                 "chr6B", "chr7B")


group.names = c( "1A","1B","2A","2B","3A","3B",
                 "4A","4B","5A","5B",
                 "6A","6B","7A","7B")

chr_length = ref_fai$V2[c(1,8,2,9,3,10,4,11,5,12,6,13,7,14 )]
library(RColorBrewer)
display.brewer.all()
df_pop = df_BC4F2

MAX_chr = max(chr_length)/10^6
for(n in 3){
  plot_geno     = gt_table[,n]
  
  message(paste0(colnames(gt_table)[n]))
  
  
  plot_chr_num  = as.numeric(as.factor( df_pop$chrom) )
  plot_pos      = df_pop$pos
  dat <- structure(list(chromosome =group.names ,chr_length/10^6)
                   , .Names = c("chromosome","size"), 
                   class = "data.frame", row.names = c(NA, -14L)) 
  
  marks <- structure(list(Chromosome = plot_chr_num, 
                          Position = plot_pos/10^6, 
                          Type = structure(as.factor(plot_geno), 
                                           .Label = c("A", "B","H","-"), class = "factor")), 
                     .Names = c("Chromosome","Position", "Type"), 
                     class = "data.frame", row.names = c(NA,-length(plot_chr_num) ))
  
  
  cols = c( "#3cb371", "#ffff00","#000080","#ffffff")
  
  marks_Type = as.numeric(marks$Type)
  
  for(i in 1:4){
    marks_Type[marks_Type == i] =  cols[i]
  }
  marks_Type
  
  
  pdf(file=paste0("chr_geno_plot_",colnames(gt_table)[n],".pdf") ,width=8,height=4)
  
  par(mar=c(3,6,3,6))
  bp <- barplot(dat$size, border=NA, col="grey80" , names.arg=group.names,
                main= colnames(gt_table)[n],
                ylab = "Physical position (Mb)", 
                ylim = c(MAX_chr,0) )
  
  
  with(marks,
       segments(
         bp[Chromosome,]-0.5,
         Position,
         bp[Chromosome,]+0.5,
         Position,
         col= marks_Type,
         lwd=2, 
         lend=1
       )
  )
  
  qtl = structure(list(Chromosome = c(13), 
                       Position = c(69359051/10^6), 
                       Type = structure(2, 
                                        .Label = c("VRN-A3"), class = "factor")), 
                  .Names = c("Chromosome","Position", "Type"), 
                  class = "data.frame", row.names = c(NA,-1L ))
  
  with(qtl,
       segments(
         bp[Chromosome,]-0.5,
         Position,
         bp[Chromosome,]+0.5,
         Position,
         col=c("#ff0000" ),
         lwd=2, 
         lend=1
       )
  )
  
  par(xpd=T)
  legend(par()$usr[2], par()$usr[4],
         legend=c("A","B","H","-","VRN-A3"), 
         pch = 15, col=c(cols,"#ff0000" ))
  dev.off()
  
}

