
library(vcfR)
library(ggpubr)
library(tidyr)
library(VennDiagram)


############
dp_limit = 10
FilterbyDP = function(b){
  filter_dp_progeny = b
  dp_pro = dp2
  colnames(dp_pro)
  gt.score_pro = gt.score
  gt.score_pro[dp_pro < filter_dp_progeny] = NA
  gt.score_filtered = gt.score_pro
  all_data = data.frame(chrom,pos,gt.score_filtered)
  #str(all_data)
  return(all_data)
}

options(scipen=10000000)
da_list = seq(0.5,5.5,by=0.5)
da_list 

data_amount_m= c(3440815256,3622408460)*2/(10^9)
data_amount_m4n5n= c(2961327742,2894475361)*2/(10^9)


data_amount = data.frame(data_amount_m,data_amount_m4n5n)

m_list = c("m","m4n5n")
da=1

res_df = data.frame(matrix(NA,nrow=length(da_list),ncol=3))

da = 1
m=1
m=2
for(m in 1:2){
  message(paste0("Processing of ",m_list[m]))
  #dir.create(da_list[da])
  # read compressed vcf file (*.vcf.gz)
  vcf <- read.vcfR(file=paste0("filtered_",m_list[m],"_samtools.vcf.recode.vcf"))
  # extract genotype data from vcf
  gt = extract.gt(vcf)
  gt[1:10,]
  dim(gt)
  # extract depyh data from vcf
  dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
  #ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
  dp[1:10,]
  # get marker information (chromosone numbers and positions)
  chrom <- getCHROM(vcf)
  pos <- getPOS(vcf)
  
  #show the first 10 SNPs of the first 10 lines 
  gt[1:10, ]
  
  #table( gt )
  
  # create a matrix of gt scores
  gt.score <- matrix(NA, nrow(gt), ncol(gt))
  gt.score[gt == "0/0"] <- -1
  #gt.score[gt == "0/1"] <- 0
  gt.score[gt == "1/1"] <- 1
  gt.score[gt == "0|0"] <- -1
  #gt.score[gt == "0|1"] <- 0
  gt.score[gt == "1|1"] <- 1
  
  #gt.score[1:10,]
  #dim(gt.score)
  #str(gt.score)
  
  # name the rows and columns of matrix
  rownames(gt.score) <- rownames(gt)
  colnames(gt.score) <- colnames(gt)
  
  
sum(na.omit(dp[,1]) )
sum(na.omit(dp[,2]) )


  #da = 57
  for(da in 1:length(da_list)){
  dp2 = dp
  dp2[,1] =  dp[,1]*(da_list[da]/data_amount[1,m])
  dp2[,2] =  dp[,2]*(da_list[da]/data_amount[2,m])
  

  all_data = FilterbyDP(dp_limit)
  all_data[all_data == 0] = NA
  df= na.omit(all_data)
  dim(df)

  res_df[da ,m] = sum ( as.numeric( df[,3] != df[,4] ) )
  res_df[da ,3] = da_list[da]
  
}
}
colnames(res_df) = c("PS1","PS1_4-5","Data_aomount")

write.csv(res_df,file=paste0("20220625_res_df_",dp_limit,".csv"))


###########Drawing results using ggplot########

options(scipen=100)
colnames(res_df) = c("PS1","PS1_4-5","Data_amount_Gb")

d.gathered <- tidyr::gather(data = res_df, 1:2, key = "Primer_set", value = "Number_of_polymorphisms")
#######
data2 = d.gathered 
gg = ggline(data2, 
            x=  "Data_amount_Gb",
            y=   "Number_of_polymorphisms",
            linetype = "Primer_set", shape = "Primer_set",
            color = "Primer_set")
gg

ggsave(gg,  file=paste0("Number_of_poly",dp_limit,".pdf"),height=4,width=4 )



########Drawing a Venn diagram############
da = 4
for(m in 1:2){
  message(paste0("Processing of ",m_list[m]))
  #dir.create(da_list[da])
  # read compressed vcf file (*.vcf.gz)
  vcf <- read.vcfR(file=paste0("filtered_",m_list[m],"_samtools.vcf.recode.vcf"))
  # extract genotype data from vcf
  gt = extract.gt(vcf)
  gt[1:10,]
  dim(gt)
  # extract depyh data from vcf
  dp <- extract.gt(vcf,element = 'DP', as.numeric = TRUE)
  #ad <- extract.gt(vcf,element = 'AD', as.numeric = TRUE)
  dp[1:10,]
  # get marker information (chromosone numbers and positions)
  chrom <- getCHROM(vcf)
  pos <- getPOS(vcf)
  
  #show the first 10 SNPs of the first 10 lines 
  gt[1:10, ]
  
  #table( gt )
  
  # create a matrix of gt scores
  gt.score <- matrix(NA, nrow(gt), ncol(gt))
  gt.score[gt == "0/0"] <- -1
  #gt.score[gt == "0/1"] <- 0
  gt.score[gt == "1/1"] <- 1
  gt.score[gt == "0|0"] <- -1
  #gt.score[gt == "0|1"] <- 0
  gt.score[gt == "1|1"] <- 1
  
  #gt.score[1:10,]
  #dim(gt.score)
  #str(gt.score)
  
  # name the rows and columns of matrix
  rownames(gt.score) <- rownames(gt)
  colnames(gt.score) <- colnames(gt)
  
  
  sum(na.omit(dp[,1]) )
  sum(na.omit(dp[,2]) )
  
  
  #da = 57
    dp2 = dp
    dp2[,1] =  dp[,1]*(da_list[da]/data_amount[1,m])
    dp2[,2] =  dp[,2]*(da_list[da]/data_amount[2,m])
    
    dp_limit = 10
    all_data = FilterbyDP(dp_limit)
    all_data[all_data == 0] = NA
    df= na.omit(all_data)
    dim(df)
    
    res_df[da ,m] = sum ( as.numeric( df[,3] != df[,4] ) )
    res_df[da ,3] = da_list[da]
    
    chrpos =  df[ df[,3] != df[,4], 1:2]
    
    
    assign(paste0(m_list[m],"_venn_list"),  paste0(chrpos$chrom,"_",chrpos$pos) )
  
  
}


eval(parse(text=paste0(  "m_5      =  m_venn_list")))
eval(parse(text=paste0(  "m4n5n_5      =  m4n5n_venn_list")))
data= list(PS1 =  m_5, 'PS1_4-5' = m4n5n_5)
venn.diagram(data, filename=paste0("venn.tiff"), 
             fill=c(5,6), 
             lty=c(1,3), 
             scaled=T, 
             cex=c(2,2,2), 
             cat.pos=c(30,330), 
             cat.dist=c(0.18,0.18), 
             cat.cex=c(1.2,1.2),
             width=3000,
             height=3000)


